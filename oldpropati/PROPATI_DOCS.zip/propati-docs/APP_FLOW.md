# APP_FLOW.md — Every Page & User Path

---

## Navigation Architecture

The app is a single HTML file with a client-side state machine. There is no URL routing — `STATE.view` and `STATE.page` control what renders.

```
STATE.view:  'landing' | 'login' | 'dashboard'
STATE.role:  'landlord' | 'tenant' | 'agent' | 'admin' | 'estate_manager'
STATE.page:  page ID within current dashboard
```

---

## 1. Landing Page (`STATE.view = 'landing'`)

**Entry point for all unauthenticated users.**

**What renders:**
- Sticky nav: PROPATI logo, search bar, type filter tabs (All/Rent/Buy/Shortlet/Commercial)
- If logged in: avatar + "My Dashboard →" button
- If logged out: "Sign in" + "List property →" buttons
- Hero section with search bar
- Listings grid (real data from `GET /api/listings`)
- Type filter pills: All / Rent / Buy / Short-let / Share / Commercial

**User paths from landing:**
- Click listing card → opens listing detail modal
- Click "Apply Now / Book Now / Request Viewing" → redirects to login
- Click "Sign in" or "List property →" → `STATE.view = 'login'`
- Logged in: click "My Dashboard →" → `enterDashboard(user)`
- Search → filters listings in place
- Change type tab → filters by listing_type

**Data loaded:** `GET /api/listings` (on first render)

---

## 2. Auth Pages (`STATE.view = 'login'`)

### 2.1 Login (`STATE.authMode = 'login'`)

**Fields:** Email, Password  
**Actions:**
- Enter → `doLogin()` → `POST /api/auth/login`
- Success → `enterDashboard(user)` based on user.role
- "Don't have an account?" → `STATE.authMode = 'signup'`
- "Forgot password?" → `STATE.authMode = 'forgot'`
- "← Back to home" → `STATE.view = 'landing'`

### 2.2 Signup (`STATE.authMode = 'signup'`)

**Fields:** Full Name, Email, Phone (optional), Password, Confirm Password  
**Role picker:** Landlord / Tenant / Buyer / Agent / Estate Manager  
**Actions:**
- Submit → `doSignup()` → `POST /api/auth/signup`
- Success → sends welcome email + WhatsApp OTP if phone provided
- Tenant with no purpose selected → shows Purpose Picker (step 2)
- "Already have an account?" → `STATE.authMode = 'login'`

### 2.3 Forgot Password (`STATE.authMode = 'forgot'`)

**Fields:** Email  
**Actions:**
- Submit → `doForgotPassword()` → `POST /api/auth/forgot-password`
- Always shows success message (prevents email enumeration)
- Reset link sent to email → user clicks → `?reset=TOKEN&uid=USER_ID` in URL
- "Remember it?" → `STATE.authMode = 'login'`

### 2.4 Purpose Picker (tenant step 2, `STATE.authStep = 2`)

Shown after login/signup for tenants if no purpose set.  
**Options:** 🏠 Rent / 🏛️ Buy / 🌴 Short-let / 🤝 Share  
**Action:** Select → `loginWithPurpose(purpose)` → enters dashboard

---

## 3. Landlord Dashboard (`STATE.role = 'landlord'`)

### Nav Items
| Page ID | Label | Data Source |
|---------|-------|-------------|
| `home` | Dashboard | Loads `myListings` |
| `properties` | My Properties | `GET /api/listings/owner/mine` |
| `rent` | Rent Collection | `GET /api/payments/transactions` |
| `listing` | Add Listing | Form only |
| `screening` | Screening Calls | Static (call scheduling pending) |
| `agreements` | Agreements | `GET /api/agreements` |
| `messages` | Messages | `GET /api/messages/conversations` |
| `verify` | Verify Property | `GET /api/verification/:id` |
| `profile` | My Profile | `GET /api/users/profile` |

### Page Flows

**`home`** — Portfolio overview
- KPI cards: properties count, rent collected, screening requests, collection %
- Recent properties list (from myListings)
- Rent overview with tenant rows
- Quick actions: Add Listing, Screen Tenants

**`properties`** — Real data from backend
- Grid of landlord's listings with status badges
- Each card: photo, title, price, verification tier, status
- Buttons: Edit (toast), Verify → navigates to `verify`

**`listing`** — Add new property
- Form: title, type (rent/sale/short-let/share/commercial), property type, address, bedrooms, bathrooms, size, price, description, amenities checkboxes
- Photo upload (up to 10, first = cover)
- Submit → `POST /api/listings` then `POST /api/listings/:id/images`
- Success → navigates to `properties`

**`verify`** — 5-step wizard
- Step 1: Upload title documents (C of O, Deed, Survey, Governor's Consent)
- Step 2: Identity verification via Prembly (NIN/BVN/DL/Voter's Card — no doc upload)
- Step 3: Record video proof with QR code
- Step 4: Schedule agent inspection (date, time, address)
- Step 5: Certified — all layers passed

**`agreements`** — Real data
- Cards per agreement: property, parties, status, dates, rent amount
- "View / Download" → opens `GET /api/agreements/:id/preview` in new tab
- "Sign Agreement" (if not yet signed) → `POST /api/agreements/:id/sign`

**`messages`** — Real-time messaging
- Left panel: conversation list
- Right panel: message thread
- 4-second polling for new messages
- Send message → `POST /api/messages/conversations/:id/messages`

**`profile`** — Account + identity verification
- Identity verification widget (NIN/BVN/DL/Voter's Card)
- Edit name and phone
- Save → `PATCH /api/users/profile`

---

## 4. Tenant Dashboard (`STATE.role = 'tenant'`)

### Purpose-Aware Navigation

The tenant nav changes based on `STATE.purpose`:

| Purpose | Extra nav items |
|---------|----------------|
| `rent` (default) | Payments, Agreements, Maintenance, Screening |
| `buy` | My Offers, Mortgage Calculator, Title Transfer, Sale Agreements |
| `shortlet` | My Bookings, Payments |
| `share` | Roommate Matches, Share Agreement |

All purposes share: Home, Find Property, Profile, Receipts, Messages

### Page Flows

**`home`** — Welcome dashboard
- Purpose switcher (4 buttons: Rent/Buy/Short-let/Share) — persisted to localStorage
- Profile completion banner (if employment or income missing)
- KPI cards: Current Home, Next Payment, Profile status
- Quick action buttons

**`search`** — Marketplace
- Filter tabs: All/Rent/Buy/Short-let/Share/Commercial
- Listing cards with "Apply & Message" button
- Apply → opens conversation with landlord

**`payments`** — Rent & Payments
- Transaction history from `GET /api/payments/transactions`
- Pay Rent button (Paystack inline — pending)

**`agreements`** — Real data
- Same structure as landlord but from tenant's perspective
- Sign button visible if landlord has signed but tenant hasn't

**`maintenance`** — Maintenance requests
- List of open/resolved tickets
- Submit new request (pending full backend wiring)

**`screening`** — Screening calls
- Upcoming calls from landlord
- Tips for a successful screening call

**`profile`** — Full employment profile
- Identity verification widget at top
- Phone verification (WhatsApp OTP)
- Edit: full name, phone, bio, employment status, employment type, employer, job title, annual income, guarantor
- Landlord preview card showing exactly what landlords see (income band, verification score)
- Save → `PATCH /api/users/tenant-profile` + `PATCH /api/users/profile`
- Security section: explains AES-256 encryption, income band masking, NDPR compliance

**`receipts`** — Payment receipts
- All transactions from `GET /api/users/receipts`
- Each: property, landlord, amount, status, reference, date

**`messages`** — Same as landlord

**`offers`** — Buyer offers (placeholder)

**`mortgage`** — Mortgage calculator
- Principal, interest rate, years → monthly payment calc (frontend only)

**`bookings`** — Short-let bookings (placeholder)

**`matches`** — Roommate matching (placeholder)

---

## 5. Agent Dashboard (`STATE.role = 'agent'`)

### Nav Items
| Page ID | Label |
|---------|-------|
| `home` | Dashboard |
| `pipeline` | Deal Pipeline |
| `listings` | Managed Listings |
| `inspections` | Inspections |
| `commissions` | Commissions |
| `clients` | My Clients |
| `reputation` | Reputation |
| `messages` | Messages |
| `profile` | My Profile |

**`home`** — KPI cards, recent deals, upcoming inspections  
**`profile`** — Identity verification + agent details (tier, approved status)  
All other pages: real structure, data pending full wiring

---

## 6. Admin Dashboard (`STATE.role = 'admin'`)

### Nav Items
| Page ID | Label |
|---------|-------|
| `overview` | Overview |
| `verification` | Verification Queue |
| `flags` | Flagged Listings |
| `disputes` | Disputes |
| `users` | Users |
| `revenue` | Revenue |
| `settings` | Settings |

**`overview`** — Platform KPIs, live activity feed, action required panel, platform health bars  
**`verification`** — Real data from `GET /api/verification/admin/queue`
- Per listing: layers status, owner info, submitted docs
- Approve Layer N → `POST /api/verification/admin/review`
- Reject → same endpoint with decision: 'rejected'
- Grant Certified → approve Layer 5

**`flags`** — Flagged listings (mock data, API exists)  
**`disputes`** — Open disputes (mock data, API exists)

---

## 7. Estate Manager Dashboard (`STATE.role = 'estate_manager'`)

### Onboarding (first time — no org exists)

3-step wizard:
1. Create Organisation: name, billing email, address, CAC number → `POST /api/orgs`
2. Choose Plan: Starter/Growth/Enterprise → `POST /api/orgs/:id/subscribe` (Paystack)
3. Done → redirect to portfolio dashboard

### Nav Items (9 screens)
| Page ID | Label |
|---------|-------|
| `home` | Portfolio Overview |
| `portfolio` | Properties |
| `rent` | Rent Ledger |
| `maintenance` | Maintenance |
| `bulk-upload` | Bulk Import |
| `agreements` | Agreements |
| `team` | Team |
| `billing` | Billing |
| `reports` | Reports |

**`home`** — KPI grid: total units, occupancy %, arrears count, open tickets  
Recent properties + open tickets + quick actions

**`portfolio`** — Property grid from `GET /api/orgs/:id/portfolio`  
Each card: photo, title, occupancy/vacant badge, verified badge, tenant name, rent amount

**`rent`** — Consolidated ledger from `GET /api/orgs/:id/ledger`  
Per unit: tenant, property, due date, amount, paid/overdue status

**`maintenance`** — Ticket queue from `GET /api/orgs/:id/tickets`  
Filter tabs: All/Open/Assigned/In Progress/Resolved  
Create ticket, update status, assign to team member

**`bulk-upload`** — CSV drag-drop import  
Column spec: title, listing_type, property_type, address, location, price, bedrooms, bathrooms, size_sqm, description  
Preview rows before import → `POST /api/orgs/:id/bulk-upload`

**`team`** — Members from `GET /api/orgs/:id/team`  
Invite form (email + role) → `POST /api/orgs/:id/invite`  
Role permissions table (manager/accountant/maintenance/owner_view)

**`billing`** — Plan cards + current subscription + org details  
Upgrade → `POST /api/orgs/:id/subscribe`

**`reports`** — Month picker → `GET /api/orgs/:id/reports/YYYY-MM`  
Returns JSON now; PDF rendering pending

---

## 8. Session Restore Flow

On every page load:
1. Check `localStorage.propati_access` — if exists, call `GET /api/auth/me`
2. If valid → `enterDashboard(user)` with saved role and purpose
3. If invalid/expired → attempt token refresh via `POST /api/auth/refresh`
4. If refresh fails → `Auth.clear()`, show landing page

This means logged-in users always land directly on their dashboard after refresh, not the landing page.

---

## 9. Cross-Role Flows

### Tenant → Landlord (via messaging)
1. Tenant finds listing on marketplace
2. Clicks "Apply & Message" → `POST /api/messages/conversations` with landlord_id + listing_id
3. Sends initial message
4. Landlord sees unread badge in nav
5. Landlord reviews tenant's profile: `GET /api/users/tenant-profile/:tenantId`
6. Landlord creates agreement: `POST /api/agreements`
7. Tenant signs: `POST /api/agreements/:id/sign`
8. Landlord signs: `POST /api/agreements/:id/sign`
9. Status → `fully_signed`

### Landlord → Admin (verification)
1. Landlord submits verification docs (Layer 1)
2. Admin receives in-app notification
3. Admin reviews in verification queue
4. Approve/reject with optional notes
5. Landlord receives email + SMS notification of decision
6. Repeat per layer up to Layer 5

### Estate Manager → Owner (reporting)
1. EM logs in, sees portfolio dashboard
2. Selects month in Reports page
3. `GET /api/orgs/:id/reports/YYYY-MM` returns collection rate, ticket resolution, portfolio stats
4. (Future: PDF download for property owner)
