# BACKEND_STRUCTURE.md — Database Schema & API Reference

---

## Project Structure

```
propati-backend/
├── src/
│   ├── index.js              ← Entry point
│   ├── routes/
│   │   ├── auth.js
│   │   ├── listings.js
│   │   ├── verification.js
│   │   ├── payments.js
│   │   ├── agreements.js
│   │   ├── messages.js
│   │   ├── users.js
│   │   └── orgs.js
│   ├── services/
│   │   ├── notifications.js  ← email + SMS + in-app
│   │   ├── encryption.js     ← AES-256-GCM
│   │   ├── identity.js       ← Prembly NIN/BVN
│   │   ├── paystack.js       ← Paystack wrapper
│   │   └── pdf.js            ← pdfkit lease generation
│   ├── middleware/
│   │   ├── auth.js           ← authenticate, requireRole
│   │   └── upload.js         ← multer + uploadToCloudinary()
│   └── db/
│       ├── index.js          ← Pool, query(), transaction()
│       ├── migrate.js        ← v1 schema (runs on boot)
│       ├── migrate_v2.js     ← conversations, messages, orgs
│       ├── migrate_v3.js     ← employment profile columns
│       ├── fix_schema.js     ← one-time column patches
│       └── seed.js           ← demo data
```

---

## Database Schema

### `users`
```sql
id                TEXT PRIMARY KEY,          -- 'usr_' + 16 hex chars
email             TEXT UNIQUE NOT NULL,
phone             TEXT UNIQUE,
password          TEXT NOT NULL,             -- bcrypt cost 12
role              TEXT NOT NULL,             -- landlord|tenant|agent|admin|estate_manager
full_name         TEXT NOT NULL,
avatar_url        TEXT,

-- KYC (encrypted)
nin_encrypted     TEXT,                      -- AES-256-GCM
nin_hash          TEXT,                      -- HMAC-SHA256 for duplicate check
nin_verified      BOOLEAN DEFAULT FALSE,
bvn_encrypted     TEXT,
id_type           TEXT,                      -- nin|passport|drivers_licence
id_number_enc     TEXT,
id_verified       BOOLEAN DEFAULT FALSE,
id_doc_url        TEXT,
phone_verified    BOOLEAN DEFAULT FALSE,

-- Employment profile (tenant)
employment_status TEXT,                      -- employed|self_employed|business_owner|student|retired|unemployed
employment_type   TEXT,                      -- full_time|part_time|contract|freelance|internship
employer_name     TEXT,
job_title         TEXT,
yearly_income     BIGINT,                    -- in Naira, NEVER sent to client directly
income_verified   BOOLEAN DEFAULT FALSE,
profile_bio       TEXT,
profile_completed BOOLEAN DEFAULT FALSE,
guarantor_name    TEXT,
guarantor_phone   TEXT,
guarantor_relationship TEXT,

-- Status
is_active         BOOLEAN DEFAULT TRUE,
is_banned         BOOLEAN DEFAULT FALSE,
ban_reason        TEXT,

-- Agent
agent_tier        TEXT DEFAULT 'standard',  -- standard|senior|probation
agent_approved    BOOLEAN DEFAULT FALSE,
agent_bio         TEXT,
agent_areas       JSONB,

-- Timestamps
created_at        TIMESTAMPTZ DEFAULT NOW(),
updated_at        TIMESTAMPTZ DEFAULT NOW(),
last_login        TIMESTAMPTZ
```

### `refresh_tokens`
```sql
id           TEXT PRIMARY KEY,
user_id      TEXT REFERENCES users(id) ON DELETE CASCADE,
token_hash   TEXT NOT NULL,              -- bcrypt hash of refresh token
expires_at   TIMESTAMPTZ NOT NULL,
created_at   TIMESTAMPTZ DEFAULT NOW()
```

### `password_resets`
```sql
id           TEXT PRIMARY KEY,
user_id      TEXT UNIQUE REFERENCES users(id) ON DELETE CASCADE,
token_hash   TEXT NOT NULL,
expires_at   TIMESTAMPTZ NOT NULL,       -- 1 hour from creation
created_at   TIMESTAMPTZ DEFAULT NOW()
```

### `phone_otps`
```sql
id           TEXT PRIMARY KEY,
user_id      TEXT REFERENCES users(id) ON DELETE CASCADE,
otp_hash     TEXT NOT NULL,             -- bcrypt hash of 6-digit OTP
expires_at   TIMESTAMPTZ NOT NULL,      -- 10 minutes from creation
created_at   TIMESTAMPTZ DEFAULT NOW()
```

### `listings`
```sql
id                TEXT PRIMARY KEY,         -- 'lst_' + 12 hex chars
owner_id          TEXT REFERENCES users(id),
agent_id          TEXT REFERENCES users(id),
title             TEXT NOT NULL,
description       TEXT,
listing_type      TEXT NOT NULL,            -- rent|sale|short-let|share|commercial
property_type     TEXT NOT NULL,            -- apartment|house|duplex|land|office|shop|warehouse
address           TEXT NOT NULL,
area              TEXT NOT NULL,            -- neighbourhood/district
state             TEXT DEFAULT 'Lagos',
price             NUMERIC NOT NULL,
price_period      TEXT,                     -- night|month|year|total
caution_deposit   NUMERIC,
service_charge    NUMERIC,
bedrooms          INTEGER,
bathrooms         INTEGER,
size_sqm          NUMERIC,
furnished         BOOLEAN DEFAULT FALSE,
amenities         JSONB,                    -- array of strings
available_from    DATE,
minimum_stay      INTEGER,                  -- for short-let, days
status            TEXT DEFAULT 'draft',     -- draft|active|suspended|deleted
verification_tier TEXT DEFAULT 'basic',     -- basic|verified|inspected|certified
is_featured       BOOLEAN DEFAULT FALSE,
views_count       INTEGER DEFAULT 0,
created_at        TIMESTAMPTZ DEFAULT NOW(),
updated_at        TIMESTAMPTZ DEFAULT NOW()
```

### `listing_images`
```sql
id           TEXT PRIMARY KEY,
listing_id   TEXT REFERENCES listings(id) ON DELETE CASCADE,
url          TEXT NOT NULL,              -- Cloudinary secure_url
public_id    TEXT,                       -- Cloudinary public_id for deletion
is_cover     BOOLEAN DEFAULT FALSE,
sort_order   INTEGER DEFAULT 0,
created_at   TIMESTAMPTZ DEFAULT NOW()
```

### `saved_listings`
```sql
id           TEXT PRIMARY KEY,
user_id      TEXT REFERENCES users(id) ON DELETE CASCADE,
listing_id   TEXT REFERENCES listings(id) ON DELETE CASCADE,
created_at   TIMESTAMPTZ DEFAULT NOW(),
UNIQUE(user_id, listing_id)
```

### `listing_flags`
```sql
id           TEXT PRIMARY KEY,
listing_id   TEXT REFERENCES listings(id) ON DELETE CASCADE,
flagged_by   TEXT REFERENCES users(id),
type         TEXT,                       -- fraud|duplicate|misleading|wrong_price|other
description  TEXT,
status       TEXT DEFAULT 'open',        -- open|reviewing|resolved
created_at   TIMESTAMPTZ DEFAULT NOW()
```

### `verifications`
```sql
id              TEXT PRIMARY KEY,
listing_id      TEXT UNIQUE REFERENCES listings(id) ON DELETE CASCADE,
owner_id        TEXT REFERENCES users(id),
l1_status       TEXT DEFAULT 'pending',  -- pending|approved|rejected
l2_status       TEXT DEFAULT 'pending',
l3_status       TEXT DEFAULT 'pending',
l4_status       TEXT DEFAULT 'pending',
l5_status       TEXT DEFAULT 'pending',
l1_doc_url      TEXT,
l2_id_type      TEXT,                    -- nin|bvn|drivers_license|voters_card
l2_verified_at  TIMESTAMPTZ,
current_layer   INTEGER DEFAULT 1,
overall_status  TEXT DEFAULT 'not_started', -- not_started|in_progress|certified|rejected
submitted_at    TIMESTAMPTZ,
updated_at      TIMESTAMPTZ DEFAULT NOW()
```

### `transactions`
```sql
id               TEXT PRIMARY KEY,       -- 'txn_' + ...
reference        TEXT UNIQUE,            -- 'PROPATI-YYYY-XXXX'
listing_id       TEXT REFERENCES listings(id),
payer_id         TEXT REFERENCES users(id),
payee_id         TEXT REFERENCES users(id),
agent_id         TEXT REFERENCES users(id),
type             TEXT,                   -- rent|sale|short_let|caution|service_charge
status           TEXT,                   -- pending|in_escrow|released|refunded|failed
amount           NUMERIC NOT NULL,
platform_fee     NUMERIC DEFAULT 0,
agent_commission NUMERIC DEFAULT 0,
payee_amount     NUMERIC,
description      TEXT,
paystack_ref     TEXT,
created_at       TIMESTAMPTZ DEFAULT NOW(),
updated_at       TIMESTAMPTZ DEFAULT NOW()
```

### `agreements`
```sql
id                  TEXT PRIMARY KEY,    -- 'agr_' + 12 hex chars
listing_id          TEXT REFERENCES listings(id),
landlord_id         TEXT REFERENCES users(id),
tenant_id           TEXT REFERENCES users(id),
agent_id            TEXT REFERENCES users(id),
type                TEXT,                -- rental|sale|short_let|share
status              TEXT DEFAULT 'draft', -- draft|pending_landlord|pending_tenant|landlord_signed|tenant_signed|fully_signed|terminated|expired
start_date          DATE,
end_date            DATE,
rent_amount         NUMERIC,
rent_period         TEXT,                -- monthly|yearly
caution_deposit     NUMERIC,
service_charge      NUMERIC,
notice_period_days  INTEGER DEFAULT 30,
special_clauses     TEXT,
template_vars       JSONB,
landlord_signed_at  TIMESTAMPTZ,
tenant_signed_at    TIMESTAMPTZ,
created_at          TIMESTAMPTZ DEFAULT NOW(),
updated_at          TIMESTAMPTZ DEFAULT NOW()
```

### `agreement_signatures`
```sql
id           TEXT PRIMARY KEY,
agreement_id TEXT REFERENCES agreements(id) ON DELETE CASCADE,
signer_id    TEXT REFERENCES users(id),
role         TEXT,                       -- landlord|tenant
ip_address   TEXT,
user_agent   TEXT,
consent_text TEXT,
signed_at    TIMESTAMPTZ DEFAULT NOW(),
checksum     TEXT                        -- SHA256 of doc_url+signer_id+signed_at
```

### `rent_schedule`
```sql
id             TEXT PRIMARY KEY,
agreement_id   TEXT REFERENCES agreements(id) ON DELETE CASCADE,
due_date       TEXT,                     -- 'YYYY-MM-DD'
amount         NUMERIC NOT NULL,
status         TEXT DEFAULT 'upcoming',  -- upcoming|paid|overdue
paid_at        TIMESTAMPTZ,
transaction_id TEXT REFERENCES transactions(id),
reminder_sent  INTEGER DEFAULT 0
```

### `notifications`
```sql
id           TEXT PRIMARY KEY,
user_id      TEXT REFERENCES users(id) ON DELETE CASCADE,
type         TEXT,                       -- welcome|rent_due|payment_received|new_message|etc.
title        TEXT,
body         TEXT,
data         JSONB,
read         BOOLEAN DEFAULT FALSE,
created_at   TIMESTAMPTZ DEFAULT NOW()
```

### `disputes`
```sql
id           TEXT PRIMARY KEY,
listing_id   TEXT REFERENCES listings(id),
raised_by    TEXT REFERENCES users(id),
against      TEXT REFERENCES users(id),
type         TEXT,                       -- caution|payment|breach|harassment|other
status       TEXT DEFAULT 'open',        -- open|reviewing|resolved|escalated
description  TEXT,
resolution   TEXT,
created_at   TIMESTAMPTZ DEFAULT NOW(),
updated_at   TIMESTAMPTZ DEFAULT NOW()
```

### `screening_calls`
```sql
id              TEXT PRIMARY KEY,
listing_id      TEXT REFERENCES listings(id),
landlord_id     TEXT REFERENCES users(id),
tenant_id       TEXT REFERENCES users(id),
scheduled_at    TIMESTAMPTZ,
status          TEXT DEFAULT 'pending',  -- pending|confirmed|completed|cancelled
notes           TEXT,
created_at      TIMESTAMPTZ DEFAULT NOW()
```

---

### V2 Tables (migrate_v2.js)

### `conversations`
```sql
id               TEXT PRIMARY KEY,       -- 'cnv_' + 12 hex chars
listing_id       TEXT REFERENCES listings(id) ON DELETE SET NULL,
landlord_id      TEXT NOT NULL REFERENCES users(id),
tenant_id        TEXT NOT NULL REFERENCES users(id),
subject          TEXT,
last_message     TEXT,
last_message_at  TIMESTAMPTZ,
unread_tenant    INTEGER DEFAULT 0,
unread_landlord  INTEGER DEFAULT 0,
status           TEXT DEFAULT 'active',  -- active|archived|blocked
created_at       TIMESTAMPTZ DEFAULT NOW(),
updated_at       TIMESTAMPTZ DEFAULT NOW()
```

### `messages`
```sql
id              TEXT PRIMARY KEY,        -- 'msg_' + 12 hex chars
conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
sender_id       TEXT NOT NULL REFERENCES users(id),
content         TEXT NOT NULL,
attachment_url  TEXT,
attachment_type TEXT,                    -- image|document|voice
is_read         BOOLEAN DEFAULT FALSE,
read_at         TIMESTAMPTZ,
created_at      TIMESTAMPTZ DEFAULT NOW()
```

### `organisations`
```sql
id                  TEXT PRIMARY KEY,    -- 'org_' + 12 hex chars
name                TEXT NOT NULL,
owner_id            TEXT REFERENCES users(id),
billing_email       TEXT,
address             TEXT,
cac_number          TEXT,
plan_tier           TEXT DEFAULT 'starter', -- starter|growth|enterprise
max_units           INTEGER DEFAULT 20,
max_seats           INTEGER DEFAULT 1,
paystack_customer_id TEXT,
created_at          TIMESTAMPTZ DEFAULT NOW(),
updated_at          TIMESTAMPTZ
```

### `org_members`
```sql
id           TEXT PRIMARY KEY,
org_id       TEXT REFERENCES organisations(id) ON DELETE CASCADE,
user_id      TEXT REFERENCES users(id),
email        TEXT,
role         TEXT,                       -- manager|accountant|maintenance|owner_view
status       TEXT DEFAULT 'pending',     -- pending|active|removed
invite_token TEXT,
invited_by   TEXT REFERENCES users(id),
joined_at    TIMESTAMPTZ,
created_at   TIMESTAMPTZ DEFAULT NOW(),
UNIQUE(org_id, user_id)
```

### `org_listings`
```sql
id           TEXT PRIMARY KEY,
org_id       TEXT REFERENCES organisations(id) ON DELETE CASCADE,
listing_id   TEXT REFERENCES listings(id) ON DELETE CASCADE,
created_at   TIMESTAMPTZ DEFAULT NOW(),
UNIQUE(org_id, listing_id)
```

### `maintenance_tickets`
```sql
id              TEXT PRIMARY KEY,        -- 'tkt_' + 12 hex chars
org_id          TEXT REFERENCES organisations(id),
listing_id      TEXT REFERENCES listings(id),
tenant_id       TEXT REFERENCES users(id),
raised_by       TEXT REFERENCES users(id),
title           TEXT NOT NULL,
description     TEXT,
category        TEXT,                    -- plumbing|electrical|structural|security|cleaning|other
priority        TEXT DEFAULT 'medium',   -- low|medium|high|urgent
status          TEXT DEFAULT 'open',     -- open|assigned|in_progress|resolved|closed
assigned_to     TEXT REFERENCES users(id),
photo_urls      TEXT[],
resolution_note TEXT,
resolved_at     TIMESTAMPTZ,
closed_at       TIMESTAMPTZ,
created_at      TIMESTAMPTZ DEFAULT NOW(),
updated_at      TIMESTAMPTZ
```

### `org_subscriptions`
```sql
id                    TEXT PRIMARY KEY,
org_id                TEXT REFERENCES organisations(id) ON DELETE CASCADE,
paystack_sub_id       TEXT UNIQUE,
plan                  TEXT,              -- starter|growth|enterprise
status                TEXT DEFAULT 'active', -- active|paused|cancelled
amount                BIGINT,            -- in kobo
current_period_start  TIMESTAMPTZ,
current_period_end    TIMESTAMPTZ,
next_billing_date     TIMESTAMPTZ,
created_at            TIMESTAMPTZ DEFAULT NOW()
```

### `email_log`
```sql
id           TEXT PRIMARY KEY,
to_email     TEXT,
subject      TEXT,
status       TEXT,                       -- sent|failed
error        TEXT,
created_at   TIMESTAMPTZ DEFAULT NOW()
```

---

## API Reference

### Standard Response Format
```json
{ "success": true, "data": "..." }
{ "success": false, "error": "message", "details": [...] }
```

### Auth Middleware
```javascript
authenticate          // requires valid JWT, attaches req.user
requireRole('landlord', 'admin')  // requires one of specified roles
optionalAuth          // attaches req.user if token present, doesn't fail
```

---

### Auth Routes (`/api/auth`)

| Method | Path | Auth | Body | Response |
|--------|------|------|------|----------|
| POST | `/signup` | — | `email, password, full_name, role, phone?` | `{ user, access_token, refresh_token }` |
| POST | `/login` | — | `email, password` | `{ user, access_token, refresh_token }` |
| POST | `/logout` | ✓ | — | `{ message }` |
| GET | `/me` | ✓ | — | `{ user }` |
| POST | `/refresh` | — | `{ refresh_token }` | `{ access_token, refresh_token, user }` |
| POST | `/forgot-password` | — | `{ email }` | `{ message }` |
| POST | `/reset-password` | — | `{ token, user_id, password }` | `{ message }` |
| POST | `/send-phone-otp` | ✓ | `{ phone? }` | `{ message }` |
| POST | `/verify-phone` | ✓ | `{ otp }` | `{ message }` |

---

### Listings Routes (`/api/listings`)

| Method | Path | Auth | Notes |
|--------|------|------|-------|
| GET | `/` | optional | Query: `type, area, min_price, max_price, bedrooms, verified, q, page, limit, sort` |
| GET | `/owner/mine` | ✓ | Landlord's own listings |
| GET | `/:id` | optional | Includes images + verification |
| POST | `/` | landlord/agent | Creates draft listing |
| PATCH | `/:id` | owner/admin | Update listing fields |
| DELETE | `/:id` | owner/admin | Soft delete |
| POST | `/:id/images` | owner/admin | Multipart upload, field name: `images`, max 10 |
| POST | `/:id/save` | ✓ | Toggle saved |
| POST | `/:id/flag` | ✓ | Body: `{ type, description? }` |

---

### Verification Routes (`/api/verification`)

| Method | Path | Auth | Notes |
|--------|------|------|-------|
| GET | `/:listing_id` | ✓ | Get verification status |
| POST | `/upload-doc` | landlord | Multipart: field `document` |
| POST | `/submit-layer1` | landlord | Marks Layer 1 as submitted |
| POST | `/inspect` | landlord | Schedule inspection |
| POST | `/verify-identity` | ✓ | Prembly lookup. Body: `{ type, number, dob? }` |
| POST | `/confirm-identity` | ✓ | Body: `{ listing_id, type, confirmed }` |
| GET | `/admin/queue` | admin | All pending verifications |
| POST | `/admin/review` | admin | Body: `{ listing_id, layer, decision, notes }` |

---

### Agreements Routes (`/api/agreements`)

| Method | Path | Auth | Notes |
|--------|------|------|-------|
| POST | `/` | landlord/agent | Create lease |
| GET | `/` | ✓ | User's agreements |
| GET | `/:id` | party/admin | Single agreement |
| POST | `/:id/sign` | party | Body: `{ consent: true }` |
| GET | `/:id/preview` | party/admin | Returns HTML |
| PATCH | `/:id` | landlord/admin | Update status/clauses |

---

### Messages Routes (`/api/messages`)

| Method | Path | Auth | Notes |
|--------|------|------|-------|
| GET | `/conversations` | ✓ | List user's conversations |
| POST | `/conversations` | ✓ | Body: `{ landlord_id, listing_id?, subject?, initial_message? }` |
| GET | `/conversations/:id` | party | Full conversation + messages |
| GET | `/conversations/:id/messages` | party | Query: `since=ISO8601, limit=50` |
| POST | `/conversations/:id/messages` | party | Body: `{ content, attachment_url? }` |
| PATCH | `/conversations/:id/read` | party | Mark all read |
| DELETE | `/conversations/:id` | party | Archive |
| GET | `/unread-count` | ✓ | Total unread count |

---

### Users Routes (`/api/users`)

| Method | Path | Auth | Notes |
|--------|------|------|-------|
| GET | `/profile` | ✓ | Own profile |
| PATCH | `/profile` | ✓ | Multipart: field `avatar`. Body: `full_name?, phone?` |
| PATCH | `/tenant-profile` | tenant | Employment fields |
| GET | `/tenant-profile/:userId` | landlord/agent | Income band only, not exact |
| GET | `/notifications` | ✓ | Last 50 |
| POST | `/notifications/read-all` | ✓ | Mark all read |
| GET | `/saved-listings` | ✓ | Tenant's saved listings |
| GET | `/agents` | — | Browse approved agents |
| GET | `/receipts` | tenant | Payment receipts |
| GET | `/admin/all` | admin | All users with pagination |
| GET | `/admin/stats` | admin | Platform stats |
| POST | `/admin/:userId/suspend` | admin | Body: `{ reason }` |
| POST | `/admin/:userId/approve-agent` | admin | Body: `{ approved: bool }` |

---

### Payments Routes (`/api/payments`)

| Method | Path | Auth | Notes |
|--------|------|------|-------|
| POST | `/initiate` | ✓ | Body: `{ listing_id, type, amount }` |
| POST | `/webhook` | — | Raw body, Paystack signature verified |
| GET | `/transactions` | ✓ | User's transactions |
| GET | `/transactions/:id` | party | Single transaction |
| POST | `/release-escrow/:id` | admin | Manual escrow release |

---

### Organisations Routes (`/api/orgs`)

| Method | Path | Auth | Notes |
|--------|------|------|-------|
| POST | `/` | ✓ | Create org |
| GET | `/mine` | ✓ | Current user's org |
| PATCH | `/:id` | manager | Update org details |
| GET | `/:id/portfolio` | member | Properties |
| GET | `/:id/team` | member | Members |
| POST | `/:id/invite` | manager | Body: `{ email, role }` |
| DELETE | `/:id/members/:uid` | manager | Remove member |
| GET | `/:id/tickets` | member | Query: `status?, priority?, category?` |
| POST | `/:id/tickets` | manager/maintenance | Create ticket |
| PATCH | `/:id/tickets/:tid` | manager/maintenance | Update ticket |
| GET | `/:id/ledger` | manager/accountant | Rent ledger |
| GET | `/:id/subscription` | manager/accountant | Plan info |
| POST | `/:id/subscribe` | manager | Body: `{ plan }` |
| POST | `/:id/bulk-upload` | manager | Multipart: field `file` (CSV) |
| GET | `/:id/reports/:month` | manager/accountant/owner_view | YYYY-MM format |
| GET | `/bulk-template.csv` | — | CSV template download |

---

## Fee Structure

```javascript
function computeFees(type, amount) {
  const rates = {
    rent:       0.10,
    sale:       amount > 20_000_000 ? 0.01 : 0.02,
    short_let:  0.05,
    commercial: 0.08,
    share:      0.05
  };
  const agentRates = {
    rent:       0.10,
    sale:       amount > 20_000_000 ? 0.01 : 0.015,
    short_let:  0.03,
    commercial: 0.05
  };
  const platformFee     = Math.round(amount * (rates[type] || 0.10));
  const agentCommission = Math.round(amount * (agentRates[type] || 0));
  const payeeAmount     = amount - platformFee;
  return { platformFee, agentCommission, payeeAmount };
}
```

---

## Notification Events

| Event | Email | SMS | In-App |
|-------|-------|-----|--------|
| `welcome` | ✓ | ✓ | ✓ |
| `rent_due` | ✓ | ✓ | ✓ |
| `payment_received` | ✓ | ✓ | ✓ |
| `escrow_released` | ✓ | ✓ | ✓ |
| `agreement_ready` | ✓ | ✓ | ✓ |
| `verification_update` | ✓ | on reject | ✓ |
| `new_message` | ✓ | first only | ✓ |
| `team_invite` | ✓ | — | — |
| `ticket_resolved` | ✓ | ✓ | ✓ |

---

## Cron Jobs

```javascript
// Runs daily at 08:00 WAT (07:00 UTC)
runRentReminders()
// → finds rent_schedule entries due in 7, 3, 1 days
// → sends email + SMS to tenant
// → marks reminder_sent = 1
// → marks overdue if past due date
```
