# FRONTEND_GUIDELINES.md — Design System

---

## Architecture

The frontend is a **single HTML file** with one `<script>` tag. All JS lives in that script. No bundler, no imports, no modules.

### State Machine Pattern
```javascript
// All app state lives here
const STATE = { view, role, page, purpose, authMode, ... }

// Only way to update state
function setState(updates) {
  Object.assign(STATE, updates);
  render(); // re-renders entire app
}

// Main render — switches on STATE.view
function render() {
  if (STATE.view === 'landing') app.innerHTML = renderLanding();
  else if (STATE.view === 'login') app.innerHTML = renderLogin();
  else if (STATE.role === 'admin') app.innerHTML = renderAdmin();
  else if (STATE.role === 'estate_manager') app.innerHTML = renderEstateManager();
  else app.innerHTML = renderDashboard();
  bindEvents();
}
```

### Event Delegation Pattern
All click events use `data-action` attributes, not inline onclick (except for complex closures):
```html
<button data-action="nav" data-page="properties">Properties</button>
<div data-action="logout">Sign Out</div>
```

```javascript
document.addEventListener('click', e => {
  const el = e.target.closest('[data-action]');
  if (!el) return;
  switch(el.dataset.action) {
    case 'nav': navigate(el.dataset.page); break;
    case 'logout': logout(); break;
    // ...
  }
});
```

---

## Colour System

### CSS Variables by Role

```css
:root {
  /* Landlord — dark, rust accent */
  --l-bg:       #0f0f0f;
  --l-surface:  #151515;
  --l-surface2: #1a1a1a;
  --l-border:   rgba(255,255,255,0.08);
  --l-text:     #f8f6f0;
  --l-muted:    #888680;
  --l-accent:   #d4622a;   /* rust orange */
  --l-accent2:  #c8920a;   /* amber */
  --l-glow:     rgba(212,98,42,0.1);

  /* Tenant — light, teal accent */
  --t-bg:       #f7f5f0;
  --t-surface:  #ffffff;
  --t-border:   #e8e4dc;
  --t-text:     #111110;
  --t-muted:    #7a7870;
  --t-accent:   #0e7c6a;   /* teal */
  --t-accent2:  #14a88e;   /* light teal */

  /* Agent — navy, gold accent */
  --a-bg:       #0d1b2e;
  --a-surface:  #0f2035;
  --a-border:   rgba(201,149,42,0.15);
  --a-text:     #e8f0f8;
  --a-muted:    #4a6880;
  --a-accent:   #c9952a;   /* gold */
  --a-accent2:  #e0b04a;   /* light gold */

  /* Shared palette */
  --green:      #2aad72;
  --green-bg:   rgba(42,173,114,0.1);
  --amber:      #c9952a;
  --amber-bg:   rgba(201,149,42,0.1);
  --red:        #e05252;
  --red-bg:     rgba(224,82,82,0.1);
  --blue:       #3b82f6;
  --blue-bg:    rgba(59,130,246,0.1);
}
```

### Admin Colours (inline, not CSS vars)
```
Background:    #0c0e12
Surface:       #13161d
Surface2:      #161a21
Border:        rgba(255,255,255,0.06)
Text:          #e8eaf0
Muted:         #9aa0b0
Cyan accent:   #00d4c8
Green:         #22c55e
Amber:         #f59e0b
Red:           #ef4444
```

### Estate Manager Colours (inline, `.em-*` classes)
```
Background:    #080E18
Surface:       #0B1220
Border:        #1A2A3A
Text:          #C8D8E8
Muted:         #5A7A9A
Blue accent:   #6EA8FE
```

### Landing Page Colours
```
Background:    #f5f3ee (warm sand)
Text:          #1a1a1a
Gold:          #c9952a
Dark hero:     #1a1a1a → #3d2810
Card bg:       white
```

---

## Typography

| Font | Usage | Load |
|------|-------|------|
| Bricolage Grotesque | Page titles, dashboard headers, card titles | Google Fonts |
| Outfit | Body text, buttons, nav items, labels | Google Fonts |
| DM Serif Display | PROPATI logo mark in sidebar | Google Fonts |
| DM Mono | Codes, references, timestamps, data | Google Fonts |
| Instrument Sans | Landing page body text, listing card details | Google Fonts |

### Font Sizes
```
Page title:    1.1rem (Bricolage Grotesque, 700)
Card title:    0.87rem (Outfit, 700)
Body:          0.82–0.85rem (Outfit, 400–500)
Small/label:   0.72–0.78rem (Outfit, 500)
Micro:         0.65–0.70rem (Outfit, 700, uppercase for labels)
Mono:          0.62–0.72rem (DM Mono)
Stat value:    1.4–2rem (Bricolage Grotesque, 800)
```

---

## Spacing

Base unit: 8px (0.5rem)

```
Micro gap:     0.3rem  (4.8px)
Small gap:     0.5rem  (8px)
Standard gap:  0.75rem (12px)
Medium gap:    1rem    (16px)
Large gap:     1.2rem  (19.2px)
Section gap:   1.6rem  (25.6px)
```

### Content Padding
```
Content area:  1.6rem 1.8rem (desktop), 1rem (mobile)
Card body:     1.1rem 1.3rem
Card head:     1rem 1.3rem
Topbar:        0.9rem 1.8rem
Sidebar:       0.8rem
```

---

## Components

### Sidebar (`.sidebar`)
```css
width: 220px (landlord) / 230px (tenant) / 240px (agent)
height: 100vh
overflow-y: auto
display: flex, flex-direction: column
```

Structure:
```
.sb-header    — logo + optional badge
.sb-user-card — avatar + name + subtitle
.sb-nav       — nav sections + items
.sb-footer    — sign out button
```

Nav item active state:
```css
/* Coloured left border line */
.nav-item.active::before {
  content: '';
  position: absolute;
  left: -8px;
  width: 3px;
  height: 16px;
  border-radius: 100px;
  background: var(--accent);
}
```

### Cards (`.card`)
```css
border-radius: 14px;
border: 1px solid var(--border);
background: var(--surface);
```

### Tags/Badges
```html
<span class="tag tag-green">Certified</span>
<span class="tag tag-amber">Pending</span>
<span class="tag tag-red">Overdue</span>
<span class="tag tag-blue">Active</span>
```

```css
.tag {
  font-size: 0.67rem;
  font-weight: 700;
  padding: 0.16rem 0.5rem;
  border-radius: 100px;
  text-transform: uppercase;
  letter-spacing: 0.04em;
}
```

### Buttons
```html
<!-- Primary action -->
<button class="btn-primary" style="background:#d4622a;color:white">Add Listing</button>

<!-- Icon button (topbar) -->
<div class="icon-btn">🔔</div>

<!-- Login page CTA -->
<button class="btn-login">Sign in →</button>
```

### Form Fields
```html
<div class="fg">
  <label class="inp-label">Field Name *</label>
  <input class="inp-field" type="text" placeholder="..."/>
</div>
```

```css
.inp-field {
  width: 100%;
  padding: 0.65rem 0.85rem;
  border-radius: 9px;
  border: 1.5px solid;
  font-family: 'Outfit', sans-serif;
  font-size: 0.85rem;
  transition: border-color 0.18s;
}
```

### Toast Notifications
```javascript
showToast('✅ Profile saved!');     // success
showToast('❌ Upload failed');      // error
showToast('⚠️ Fill required fields'); // warning
```

Bottom-right, auto-dismisses after 3 seconds.

---

## Layout System

### Dashboard Shell
```
.app-layout (display:flex, height:100vh)
├── .sidebar (fixed width by role)
│   └── [mobile: position:fixed, slides in from left]
└── .main-area (flex:1, display:flex, flex-direction:column)
    ├── .topbar (sticky header)
    └── .content-area (overflow-y:auto, padding)
```

### Grid Utilities
```css
.dash-grid { display: grid; grid-template-columns: 1.6fr 1fr; gap: 1rem; }
.g4        { display: grid; grid-template-columns: repeat(4,1fr); gap: 0.75rem; }
```

---

## Mobile Breakpoints

```css
@media (max-width: 768px) {
  /* Sidebar slides in from left with overlay */
  /* Hamburger ☰ appears in topbar */
  /* Grids collapse to 1-2 columns */
  /* Touch targets minimum 44px */
  /* Modals become bottom sheets */
  /* Filter bars scroll horizontally */
  /* Tables scroll horizontally */
}

@media (max-width: 480px) {
  /* Single column everything */
  /* Further font size reductions */
}
```

Mobile sidebar toggle:
```javascript
function toggleMobileSidebar() {
  document.getElementById('mainSidebar').classList.toggle('open');
  document.getElementById('sidebarOverlay').classList.toggle('visible');
}
```

---

## Animation

```css
@keyframes lp-fade-up {
  from { opacity: 0; transform: translateY(18px); }
  to   { opacity: 1; transform: translateY(0); }
}
.fade-up { animation: lp-fade-up 0.5s ease both; }

/* Stagger delays */
.fade-up-1 { animation-delay: 0.05s; }
.fade-up-2 { animation-delay: 0.10s; }
.fade-up-3 { animation-delay: 0.15s; }
```

Transition standard: `transition: all 0.18s`  
Hover lift: `transform: translateY(-1px)` on buttons  
Active press: `transform: translateY(0)`

---

## Loading States

```javascript
// Show loading placeholder
if (DATA.myListings === null) {
  loadMyListings();
  return `<div style="padding:2rem;text-align:center">⏳ Loading...</div>`;
}

// Empty state
if (!DATA.myListings.length) {
  return `<div>No listings yet.</div>`;
}

// Data ready
return DATA.myListings.map(l => listingCard(l)).join('');
```

---

## Verification Score Display

Used in tenant profiles and landlord views:

```javascript
const score = [u.nin_verified, u.id_verified, u.income_verified, u.profile_completed]
  .filter(Boolean).length;

const color = score >= 3 ? '#22c55e' : score >= 2 ? '#f59e0b' : '#ef4444';
const label = score >= 3 ? 'Strong Profile' : score >= 2 ? 'Good Profile' : 'Incomplete';
```

---

## Adding a New Page

1. Add nav item to `NAV_CONFIG` in the appropriate role section
2. Add `case 'page-id':` in the `renderScreen(role, page)` switch
3. Add data load in `navigate(page)` function if needed
4. Add `DATA.myData = null` in the DATA object
5. Create `loadMyData()` and `renderMyPage()` functions
