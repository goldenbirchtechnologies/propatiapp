# IMPLEMENTATION_PLAN.md — Build Sequence

**Current status:** Core platform live. Auth, listings, verification, messaging, agreements, tenant profiles, estate manager B2B all working.

---

## Phase 1 — Critical Missing Flows (Week 1–2)

These are features where the UI exists but the backend connection is broken or missing.

### 1.1 Paystack Rent Collection — Tenant Payment Flow
**Why:** Tenants have a Payments screen but the Pay button does nothing. This is the core revenue mechanism.

Steps:
1. Wire "Pay Rent" button → `POST /api/payments/initiate` with `{ listing_id, agreement_id, amount }`
2. Receive `authorization_url` from Paystack
3. Open Paystack inline popup (load `https://js.paystack.co/v1/inline.js`)
4. On payment success callback → update UI to show "Payment in escrow"
5. Paystack fires webhook → backend updates `transactions.status = 'in_escrow'`
6. After 7 days (or admin releases) → `transactions.status = 'released'`
7. Add receipt to tenant's receipts list

**Files to edit:** `src/routes/payments.js`, `index.html` (tenant payments screen)  
**Test:** Pay ₦1 on test mode, verify transaction in DB, verify receipt shows up

---

### 1.2 Agent Listings Screen — Real Data
**Why:** Agent dashboard shows placeholder listings, not real data.

Steps:
1. Add `loadAgentListings()` function → `GET /api/listings?agent_id=USER_ID` (add this filter to backend)
2. Wire `case 'listings':` in agent screen renderer
3. Add agent_id filter to `GET /api/listings` query in `src/routes/listings.js`

**Files to edit:** `src/routes/listings.js`, `index.html` (agent listings case)

---

### 1.3 Admin Stats — Real Data
**Why:** Admin overview shows hardcoded numbers ("48,291 users", "₦2.1B GMV"). Should be live.

Steps:
1. Add `loadAdminStats()` → `GET /api/users/admin/stats`
2. Replace mock KPI cards with real data
3. Add loading state

**Files to edit:** `index.html` (admin overview case)

---

### 1.4 Notifications Bell — Real Dropdown
**Why:** Bell icon shows dot but clicking does nothing.

Steps:
1. Add `loadNotifications()` → `GET /api/users/notifications`
2. Click bell → show dropdown with last 10 notifications
3. "Mark all read" button → `POST /api/users/notifications/read-all`
4. Update unread badge count
5. Poll unread count every 30 seconds

**Files to edit:** `index.html` (topbar, bindEvents)

---

## Phase 2 — User Experience Completions (Week 2–3)

### 2.1 Tenant Application Flow — Formal Application Record
**Why:** "Apply & Message" opens a conversation but there's no formal application status. Landlords can't see all applicants for a listing.

Steps:
1. Add `applications` table to DB:
   ```sql
   id, listing_id, tenant_id, landlord_id, status (pending|approved|rejected|withdrawn),
   message, created_at
   ```
2. `POST /api/applications` → create application + start conversation
3. `GET /api/applications?listing_id=X` → landlord sees all applicants
4. Approve → `PATCH /api/applications/:id` with `{ status: 'approved' }` → triggers agreement creation prompt
5. Add "Applications" tab to landlord screening page

**Files to edit:** New `src/routes/applications.js`, `src/db/migrate.js` (or new migrate file), `index.html`

---

### 2.2 Landlord — Create Agreement from Application
**Why:** Currently landlords can create agreements but there's no UI flow linking an approved application to a new agreement.

Steps:
1. On application approval → show modal "Create Agreement for [tenant name]?"
2. Pre-fill agreement form with tenant_id, listing_id
3. `POST /api/agreements` with pre-filled data
4. Success → show agreement in agreements list with "Awaiting tenant signature" status

**Files to edit:** `index.html` (landlord screening + agreements)

---

### 2.3 Maintenance Requests — Tenant Submission
**Why:** Tenant maintenance page shows "No requests yet" with no way to submit one.

Steps:
1. Add "Submit Request" button/form
2. `POST /api/maintenance` (new endpoint) OR wire to estate manager tickets if property is in an org
3. Form: title, category, description, photo upload
4. Show submitted tickets with status

**Files to edit:** `src/routes/` (new maintenance route for non-org properties), `index.html`

---

### 2.4 Password Reset Frontend Flow
**Why:** Backend forgot-password flow is complete but the frontend doesn't handle the `?reset=TOKEN&uid=ID` URL that gets emailed.

Steps:
1. On app load, check `window.location.search` for `?reset=` param
2. If found → set `STATE.authMode = 'reset'`, show reset password form
3. Form: new password + confirm → `POST /api/auth/reset-password`
4. Success → redirect to login with success message

**Files to edit:** `index.html` (checkSession or initial load function, add reset mode to renderLogin)

---

### 2.5 Landlord — Tenant Screening Integration
**Why:** "Screen Tenants" button exists in landlord home but goes to a static placeholder page.

Steps:
1. Load applications for landlord's listings
2. Each applicant card shows: tenant name, verification score, income band, employment status
3. "View Full Profile" → opens `viewTenantProfile(tenantId)` sheet
4. "Schedule Call" → creates screening call record
5. "Approve" → creates agreement

---

## Phase 3 — B2B Completions (Week 3–4)

### 3.1 Estate Manager — PDF Report Generation
**Why:** Reports endpoint returns JSON. Owners expect a downloadable PDF.

Steps:
1. Install puppeteer: `npm install puppeteer`
2. In `src/routes/orgs.js` `/:id/reports/:month`:
   - Build HTML report template from existing JSON data
   - Use puppeteer to render to PDF buffer
   - Upload PDF buffer to Cloudinary
   - Return `{ url: cloudinary_pdf_url }`
3. Frontend "Download PDF" button opens the URL

**Files to edit:** `src/routes/orgs.js`, add puppeteer to `package.json`

---

### 3.2 Estate Manager — Org Listings Link
**Why:** Properties imported via bulk upload are linked to org, but individually added listings by the EM aren't automatically linked.

Steps:
1. After `POST /api/listings` by estate_manager role → automatically insert into `org_listings`
2. Add "Add to Portfolio" button in EM portfolio screen for unlinked listings

**Files to edit:** `src/routes/listings.js`, `index.html` (EM portfolio screen)

---

### 3.3 Paystack Subscription Webhooks — Org Plans
**Why:** Org subscription currently updates optimistically (before payment confirmed).

Steps:
1. Add webhook handler for `subscription.create`, `invoice.payment_failed`, `subscription.disable`
2. Update `org_subscriptions.status` based on webhook events
3. Downgrade org if payment fails (reduce `max_units`, `max_seats`)

**Files to edit:** `src/routes/payments.js`

---

## Phase 4 — Polish & Production Hardening (Week 4–5)

### 4.1 Email Activation
**Status:** Code written, just needs env vars set.

Steps:
1. Add `GMAIL_USER` and `GMAIL_APP_PASSWORD` to Railway variables
2. Test welcome email fires on signup
3. Test reset email fires on forgot password
4. Optionally: switch to SendGrid for higher deliverability (`npm install @sendgrid/mail`)

---

### 4.2 WhatsApp OTP Activation
**Status:** Code written, just needs env vars set.

Steps:
1. Sign up at twilio.com
2. Join WhatsApp sandbox: text "join [word]" to +14155238886
3. Add `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_WHATSAPP_FROM` to Railway
4. For production: apply for WhatsApp Business API number through Twilio

---

### 4.3 NIN/BVN Verification Activation
**Status:** Mock mode active. Works correctly in dev.

Steps:
1. Sign up at identitypass.prembly.com
2. Add `PREMBLY_API_KEY` and `PREMBLY_APP_ID` to Railway
3. Mock mode auto-disables when keys are present

---

### 4.4 Custom Domain
Steps:
1. Buy domain (e.g. propati.ng) from NiRA or any registrar
2. Vercel: Settings → Domains → add custom domain → update DNS
3. Railway: Settings → Networking → add custom domain (api.propati.ng)
4. Update `FRONTEND_URL` in Railway vars
5. Update `const API = '...'` in frontend HTML

---

### 4.5 Error Monitoring
Steps:
1. Sign up at sentry.io (free tier)
2. `npm install @sentry/node`
3. Add to `src/index.js` before routes
4. Will catch all unhandled errors in production

---

### 4.6 Frontend Performance
Steps:
1. Split the HTML file → keep it single file but lazy-load role dashboards as template strings only when needed
2. Add `<link rel="preconnect" href="https://fonts.googleapis.com">` to head
3. Add `loading="lazy"` to listing images
4. Consider moving to Cloudinary image transformations for auto-resizing

---

## Phase 5 — Growth Features (Month 2+)

### 5.1 Search Improvements
- ElasticSearch or PostgreSQL full-text search with `tsvector`
- Area autocomplete (Lagos neighbourhoods list)
- Map view (Mapbox or Google Maps embed)
- Price history charts per area

### 5.2 Agent Mobile App
- React Native or PWA wrapper around existing web
- Push notifications via FCM
- Document scanner for verification

### 5.3 Landlord Analytics
- Listing performance (views, enquiries, applications)
- Comparable pricing in the area
- Vacancy trend

### 5.4 NIN Verification — Direct NIMC Integration
- Apply for NIMC API access (requires CAC registration)
- More reliable than Prembly for high volumes
- Lower cost at scale

### 5.5 Escrow as a Service — CAC Registration
- Register PROPATI as payment solution provider with CBN
- Full escrow licence
- Enable Paystack as collection agent

---

## Deployment Checklist (Before Each Release)

```bash
# 1. Test locally
node --check src/index.js
npm run dev  # start server
# test key flows manually

# 2. Push to GitHub
git add -A
git commit -m "Description of changes"
git push
# Railway auto-deploys in ~45 seconds

# 3. Verify deployment
curl https://propati-backend-production.up.railway.app/health
# Should return: {"status":"healthy","database":"connected"}

# 4. Run migrations if schema changed
railway run node src/db/migrate_v3.js  # (or new migration file)

# 5. Test in production
# Login with chidi@propati.ng / Chidi1234!
# Test the specific flow that changed

# 6. Update frontend if changed
# Replace index.html on Vercel
# Vercel auto-deploys on git push if connected
```

---

## Known Bugs to Fix

| Bug | Impact | File | Fix |
|-----|--------|------|-----|
| Listing type select uses wrong values | Upload broken | `index.html` | Fixed in v6 |
| `role is not defined` in renderLandlordScreen | Agreements crash | `index.html` | Fixed in v6 |
| `/listings/my` 404 | My listings broken | `index.html` | Fixed in v6 |
| `loadEmOrg` infinite loop on 404 | EM dashboard freezes | `index.html` | Fixed in v6 |
| Admin activity feed is mock data | — | `index.html` | Phase 1.3 |
| Tenant maintenance can't submit | — | `index.html` | Phase 2.3 |
| Password reset URL not handled | — | `index.html` | Phase 2.4 |
