# PRD — PROPATI Product Requirements Document

**Version:** 1.0  
**Last Updated:** March 2026  
**Status:** In Production

---

## 1. Product Overview

PROPATI is a Nigerian property platform that combines a verified property marketplace with full property management tooling. It serves five distinct user roles operating on a single unified platform.

**Core promise:** Every listing on PROPATI has passed at least one layer of a 5-layer verification system. Tenants can transact safely. Landlords can manage their entire portfolio digitally.

---

## 2. User Roles

### 2.1 Landlord
Private property owners listing 1–20 properties for rent, sale, or short-let.

**Can:**
- List and manage properties
- Upload documents for verification
- Screen and approve tenants via video calls
- Create and send digital lease agreements
- Collect rent via Paystack escrow
- Message tenants directly

**Cannot:**
- Manage properties owned by others
- Access other landlords' tenants

---

### 2.2 Tenant / Buyer
Individuals looking to rent, buy, share, or book short-let properties.

**Can:**
- Browse and filter marketplace listings
- Apply for properties (message landlord)
- Complete employment profile for landlord assessment
- Sign digital agreements
- Pay rent via escrow
- Raise maintenance requests
- Verify NIN/BVN for identity badge

**Cannot:**
- List their own properties
- See exact salary of other tenants

---

### 2.3 Agent
Licensed property agents who list and manage properties on behalf of landlords.

**Can:**
- List properties (on behalf of landlord)
- Earn commissions (tracked in platform)
- Manage a client pipeline
- Build public reputation score

**Cannot:**
- Collect rent directly (goes through escrow)
- Access landlord's bank details

---

### 2.4 Admin
PROPATI staff with platform-wide access.

**Can:**
- Review verification queue (approve/reject each layer)
- Suspend or ban users
- Approve agent applications
- View platform-wide stats
- Manage disputes
- Release escrow manually

---

### 2.5 Estate Manager (B2B SaaS)
Property management companies managing portfolios of 20–1000+ units on behalf of building owners.

**Can:**
- Create an organisation (company account)
- Import bulk property listings via CSV
- Manage entire rent collection across portfolio
- Assign maintenance tickets to staff
- Invite team members (accountant, maintenance, owner_view roles)
- Generate monthly PDF owner reports
- Subscribe to a paid plan (Starter/Growth/Enterprise)

---

## 3. Features In Scope

### 3.1 Marketplace
- Property listing cards with photos, price, bedrooms, verification badge
- Filter by: type (rent/buy/shortlet/share/commercial), area, price range, bedrooms, verified only
- Full-text search across title, area, address
- Sort by: newest, price asc/desc, most verified
- Listing detail page with full specs, amenities, landlord info
- Save to favourites
- Flag/report listing
- Apply & Message flow (starts conversation with landlord)

### 3.2 Property Verification (5 Layers)
1. **Layer 1 — Documents:** Title deed, C of O, Survey Plan, Governor's Consent upload
2. **Layer 2 — Identity:** NIN/BVN/Driver's License/Voter's Card via Prembly IdentityPass API. No document upload — live API lookup with user confirmation
3. **Layer 3 — Live Video Proof:** Landlord records video inside property holding PROPATI QR code
4. **Layer 4 — Agent Physical Inspection:** Registered PROPATI agent visits property in person
5. **Layer 5 — Certification:** Admin final review, grants ⭐ Certified badge

**Trust tiers:** Basic → Verified (Layers 1-2) → Inspected (Layers 1-4) → Certified (all 5)

### 3.3 Identity Verification (Personal)
Separate from property verification. Any user (all roles) can verify their personal identity.
- Supported: NIN, BVN, Driver's License, Voter's Card
- Via Prembly IdentityPass API
- Shows ✅ Verified badge on profile
- In mock mode when `PREMBLY_API_KEY` not set

### 3.4 Messaging
- Real-time conversations between landlords and tenants
- Linked to specific listing
- 4-second polling for new messages
- SMS notification on first unread message (Termii)
- WhatsApp notification option (Twilio)
- Unread count badge in nav

### 3.5 Digital Agreements
- Landlord creates lease for a specific tenant+listing
- System generates formatted agreement (HTML preview, PDF download)
- Both parties sign electronically (records: timestamp, IP address, user agent, consent text, SHA256 checksum)
- Status flow: draft → pending_landlord → pending_tenant → fully_signed
- Agreement accessible by both parties at any time

### 3.6 Tenant Profile
- Employment status (employed/self-employed/student/etc.)
- Employment type (full-time/part-time/contract/freelance)
- Employer name + job title
- Annual income (stored encrypted — landlords only see band: e.g. ₦3M–₦6M/yr)
- Guarantor details (name, phone, relationship)
- Bio/introduction
- Profile completion score (0–4) based on: NIN verified, ID verified, income set, profile complete
- Landlord view endpoint masks exact salary, returns income band only

### 3.7 Rent Collection (Partial — UI exists, payment flow pending)
- Paystack integration for card payments
- Escrow: payment held until landlord confirms move-in
- 10% platform fee + 10% agent commission (if applicable)
- Escrow release after 7 days or admin manual release
- Rent reminders via SMS/email 7 days, 3 days, 1 day before due date (automated cron)

### 3.8 Estate Manager B2B
- Organisation creation (name, billing email, address, CAC number)
- 3-step onboarding wizard (create org → choose plan → done)
- **Portfolio dashboard:** occupancy rate, arrears, maintenance KPIs
- **Rent ledger:** consolidated view of all rent payments across portfolio
- **Maintenance tickets:** create, assign, track status (open/assigned/in_progress/resolved/closed)
- **Bulk property import:** CSV upload (max units per plan)
- **Team management:** invite members, assign roles, seat limits by plan
- **Billing:** Paystack subscription (Starter ₦25k/mo, Growth ₦60k/mo, Enterprise ₦150k/mo)
- **Monthly reports:** JSON now, PDF rendering pending

### 3.9 Notifications
- In-app (stored in `notifications` table, bell icon in nav)
- Email via Nodemailer (Gmail or SMTP)
- SMS via Termii (Nigerian gateway, E.164 phone normalisation)
- WhatsApp OTP via Twilio (signup verification, 6-digit, 10-minute expiry)

### 3.10 Auth
- Signup with role selection
- Email welcome notification on registration
- Phone OTP via WhatsApp on signup (if phone provided)
- Forgot password → email reset link (1 hour expiry)
- JWT access tokens (15min) + refresh tokens (7 days, auto-rotate)
- Session restore on browser refresh (localStorage)
- Purpose persistence for tenants (rent/buy/shortlet/share)

---

## 4. Features OUT OF Scope (v1)

The following are explicitly deferred and should not be built until core flows are stable:

- **Mobile apps** — web-responsive only
- **Push notifications** — SMS/email only, no FCM/APNs
- **In-platform video calling** — screening calls are external (Zoom/WhatsApp)
- **Property price valuation** — no AI pricing suggestions
- **Mortgage calculator backend** — UI only, no lender API integration
- **Title transfer tracking** — UI only
- **Dispute resolution workflow** — admin views disputes but no formal workflow yet
- **Agent leaderboard** — reputation score is placeholder
- **WhatsApp chatbot** — OTP only, not a full chatbot
- **BVN linking for payments** — Paystack only, no direct bank debit
- **CAC business verification** — field collected but not verified via API
- **FIRS tax receipts** — out of scope for v1
- **Multi-language support** — English only
- **Dark mode** — each dashboard has its own colour theme

---

## 5. Success Metrics (MVP)

| Metric | Target |
|--------|--------|
| Verified listings | 500 by month 3 |
| Active tenants | 2,000 by month 3 |
| Completed agreements | 200 by month 3 |
| B2B clients (Estate Manager) | 25 by month 6 |
| B2B MRR target | ₦1.6M/month |
| Platform GMV (month 6) | ₦500M |
| Verification completion rate | >60% of submitted listings |

---

## 6. Compliance & Legal

- **NDPR compliant** — NIN/BVN encrypted, income band masking, data processing disclosure on profile
- **Electronic signatures** — timestamped, IP-logged, legally binding under Nigerian law
- **Escrow** — requires CAC registration as financial intermediary (pending)
- **Paystack** — live account with webhook verification
- **Prembly IdentityPass** — NIN/BVN lookup, NDPR compliant data processor
