# TECH_STACK.md — Exact Versions & Technology Choices

---

## Frontend

| Technology | Version | Notes |
|-----------|---------|-------|
| HTML/CSS/JS | Vanilla — no framework | Single file, no build step |
| Fonts | Google Fonts | Bricolage Grotesque, Outfit, DM Serif Display, DM Mono |

**No npm. No webpack. No React. No TypeScript.**

The entire frontend is one HTML file (`index.html`, ~420KB, ~7000 lines). It loads in a browser directly. Deployment is a file upload to Vercel.

---

## Backend

| Technology | Version | Purpose |
|-----------|---------|---------|
| Node.js | 22.x (Railway default) | Runtime |
| Express | ^4.18.2 | HTTP server |
| pg | ^8.11.3 | PostgreSQL client |
| pg-pool | ^3.6.1 | Connection pooling |
| bcryptjs | ^2.4.3 | Password hashing (cost factor 12) |
| jsonwebtoken | ^9.0.2 | JWT access + refresh tokens |
| cors | ^2.8.5 | CORS middleware |
| dotenv | ^16.4.1 | Environment variables |
| express-rate-limit | ^7.2.0 | Rate limiting (300 req/15min global, 10 auth) |
| express-validator | ^7.0.1 | Input validation |
| helmet | ^7.1.0 | Security headers |
| axios | ^1.6.7 | HTTP client (Prembly, Termii, Twilio) |
| uuid | ^9.0.0 | ID generation |
| morgan | ^1.10.0 | HTTP request logging |
| multer | ^1.4.5-lts.1 | Multipart file parsing (memory storage) |
| cloudinary | ^2.0.1 | Image/document cloud storage |
| winston | ^3.11.0 | Structured logging |
| winston-daily-rotate-file | ^4.7.1 | Log rotation |
| express-mongo-sanitize | ^2.2.0 | NoSQL injection protection |
| hpp | ^0.2.3 | HTTP parameter pollution protection |
| express-slow-down | ^1.6.0 | Progressive request throttling |
| compression | ^1.7.4 | Gzip response compression |
| pdfkit | ^0.14.0 | PDF generation (lease agreements) |
| nodemailer | ^6.9.9 | Email sending |
| csv-parse | ^5.5.5 | CSV parsing for bulk upload |
| node-cron | ^3.0.3 | Scheduled jobs (rent reminders) |

**No ORM.** All queries are raw SQL with parameterised `$1, $2` placeholders.

---

## Database

| Technology | Version | Notes |
|-----------|---------|-------|
| PostgreSQL | 15.x (Supabase managed) | Cloud hosted |
| Supabase | Latest | Hosting only — using direct pg driver, not Supabase client |

**Connection:** `DATABASE_URL` connection string (pooler URL from Supabase)  
**SSL:** `rejectUnauthorized: false` (required for Supabase pooler)  
**Pool size:** 20 connections max  
**Idle timeout:** 30,000ms  
**Connection timeout:** 5,000ms

---

## Third-Party Services

| Service | Purpose | Config |
|---------|---------|--------|
| **Cloudinary** | Image & document storage | `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET` |
| **Paystack** | Payments, subscriptions, webhooks | `PAYSTACK_SECRET_KEY` |
| **Termii** | Nigerian SMS gateway | `TERMII_API_KEY`, `TERMII_SENDER_ID=PROPATI` |
| **Twilio** | WhatsApp OTP delivery | `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_WHATSAPP_FROM` |
| **Prembly IdentityPass** | NIN/BVN/DL/Voter's Card verification | `PREMBLY_API_KEY`, `PREMBLY_APP_ID` |
| **Nodemailer + Gmail** | Transactional email | `GMAIL_USER`, `GMAIL_APP_PASSWORD` |

**Mock modes:** All third-party services degrade gracefully when API keys are missing — they log to console instead of calling the real API. This means development works with zero credentials configured.

---

## Infrastructure

| Layer | Service | Notes |
|-------|---------|-------|
| Frontend hosting | Vercel | Free tier, auto-deploy on git push |
| Backend hosting | Railway | `propati-backend-production.up.railway.app` |
| Database | Supabase | West Europe region (closest to Nigeria) |
| File storage | Cloudinary | Free tier, `propati/` folder |
| Domain | Custom (pending) | Currently on `.vercel.app` and `.railway.app` |

---

## Security Architecture

### Authentication
- **Access token:** JWT, 15-minute expiry, signed with `JWT_SECRET` (64-char hex)
- **Refresh token:** JWT, 7-day expiry, signed with `JWT_REFRESH_SECRET` (different key), stored hashed in DB
- **Token rotation:** new refresh token issued on every refresh
- **Session invalidation:** all refresh tokens deleted on logout

### Field-Level Encryption
Algorithm: **AES-256-GCM** (authenticated encryption)  
Key: 32 bytes from `ENCRYPTION_KEY` env var  
Format stored: `base64(iv):base64(authTag):base64(ciphertext)`

Fields encrypted:
- `users.nin_encrypted` — National Identity Number
- `users.bvn_encrypted` — Bank Verification Number
- `users.id_number_enc` — other ID numbers

**Lookup hashing:** HMAC-SHA256 of NIN stored separately (`nin_hash`) for duplicate checks without decryption.

### Income Privacy
- Exact annual income stored as integer in `users.yearly_income`
- `GET /api/users/tenant-profile/:id` endpoint returns `income_band` (string like "₦3M–₦6M/yr") only
- Exact figure never sent to any client

### Rate Limiting
- Global: 300 requests / 15 minutes per IP
- Auth endpoints: 10 requests / 15 minutes per IP (counts failed attempts only)
- Progressive slowdown: +100ms delay per request over 50 req/15min

---

## Dev Environment

```bash
# Required
node --version  # 18+ required
npm --version   # 8+

# Backend setup
cd propati-backend
npm install
cp .env.example .env
# Edit .env with your DATABASE_URL etc.
npm run dev     # nodemon src/index.js

# Run migrations
node src/db/migrate_v2.js
node src/db/migrate_v3.js

# Seed demo data
npm run seed

# Frontend
# No build step — just open index.html in a browser
# Or serve with: npx serve .
```

---

## Environment Variables Reference

```bash
# Required — app won't start in production without these
NODE_ENV=production
DATABASE_URL=postgresql://postgres.xxx:[password]@aws-0-eu-west-2.pooler.supabase.com:5432/postgres
JWT_SECRET=<64-char hex>
JWT_REFRESH_SECRET=<different 64-char hex>
ENCRYPTION_KEY=<64-char hex — 32 bytes>

# Required — features won't work without these
CLOUDINARY_CLOUD_NAME=xxx
CLOUDINARY_API_KEY=xxx
CLOUDINARY_API_SECRET=xxx
PAYSTACK_SECRET_KEY=sk_live_xxx
FRONTEND_URL=https://propati-frontend.vercel.app

# Optional — services degrade to mock/log mode without these
GMAIL_USER=noreply@propati.ng
GMAIL_APP_PASSWORD=xxxx xxxx xxxx xxxx
TERMII_API_KEY=xxx
TERMII_SENDER_ID=PROPATI
TWILIO_ACCOUNT_SID=ACxxx
TWILIO_AUTH_TOKEN=xxx
TWILIO_WHATSAPP_FROM=+14155238886
PREMBLY_API_KEY=xxx
PREMBLY_APP_ID=xxx

# Tunable
RATE_LIMIT_MAX=300
AUTH_RATE_LIMIT_MAX=10
MAX_FILE_SIZE_MB=10
MAX_VIDEO_SIZE_MB=100
CLOUDINARY_FOLDER=propati
JWT_EXPIRES_IN=15m
JWT_REFRESH_EXPIRES_IN=7d
PORT=3000
```
