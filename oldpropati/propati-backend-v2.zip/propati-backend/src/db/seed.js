// src/db/seed.js — PostgreSQL demo seed
require('dotenv').config();
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { query, transaction } = require('./index');
const { migrate } = require('./migrate');
const { encryptField, hashForLookup } = require('../services/encryption');

async function seed() {
  console.log('🌱 Seeding PROPATI database (PostgreSQL)...');
  await migrate();

  const hash = (pw) => bcrypt.hash(pw, 10);

  const users = [
    { id:'usr_admin_001', email:'admin@propati.ng', phone:'08000000001', password:await hash('Admin1234!'), role:'admin', full_name:'Emeka Okafor', nin_verified:true, id_verified:true },
    { id:'usr_landlord_001', email:'chidi@propati.ng', phone:'08012345678', password:await hash('Chidi1234!'), role:'landlord', full_name:'Chidi Okonkwo', nin_verified:true, id_verified:true },
    { id:'usr_tenant_001', email:'adaeze@propati.ng', phone:'08087654321', password:await hash('Adaeze1234!'), role:'tenant', full_name:'Adaeze Obi', nin_verified:true, id_verified:true },
    { id:'usr_agent_001', email:'akin@propati.ng', phone:'08011112222', password:await hash('Akin1234!'), role:'agent', full_name:'Akin Balogun', nin_verified:true, id_verified:true, agent_tier:'senior', agent_approved:true, agent_bio:'Senior PROPATI agent. 14 deals closed in March 2026.', agent_areas:JSON.stringify(['Lekki','Victoria Island','Ikoyi']) },
    { id:'usr_landlord_002', email:'rita@propati.ng', phone:'08033334444', password:await hash('Rita1234!'), role:'landlord', full_name:'Rita Sule', nin_verified:true, id_verified:true },
  ];

  for (const u of users) {
    await query(`
      INSERT INTO users (id,email,phone,password,role,full_name,nin_verified,id_verified,agent_tier,agent_approved,agent_bio,agent_areas)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
      ON CONFLICT (email) DO NOTHING
    `, [u.id, u.email, u.phone, u.password, u.role, u.full_name,
        u.nin_verified||false, u.id_verified||false,
        u.agent_tier||'standard', u.agent_approved||false,
        u.agent_bio||null, u.agent_areas||null]);
  }
  console.log(`  ✓ ${users.length} users`);

  const listings = [
    { id:'lst_001', owner_id:'usr_landlord_001', title:'4-Bed Duplex, Lekki Phase 1', description:'Spacious 4-bedroom duplex. 24hr security, 3 parking spaces.', listing_type:'rent', property_type:'duplex', address:'12 Admiralty Way, Lekki Phase 1', area:'Lekki Phase 1', price:800000, price_period:'year', caution_deposit:800000, bedrooms:4, bathrooms:3, size_sqm:280, furnished:false, status:'active', verification_tier:'certified', amenities:JSON.stringify(['Generator','Borehole','Security','CCTV','Swimming Pool']) },
    { id:'lst_002', owner_id:'usr_landlord_001', title:'Luxury 3-Bed Apartment, Victoria Island', description:'Premium serviced apartment. Ocean views, rooftop pool.', listing_type:'short-let', property_type:'apartment', address:'45 Adeola Odeku St, Victoria Island', area:'Victoria Island', price:85000, price_period:'night', caution_deposit:170000, bedrooms:3, bathrooms:3, size_sqm:190, furnished:true, status:'active', verification_tier:'verified', amenities:JSON.stringify(['Pool','Gym','Concierge','Generator','WiFi']) },
    { id:'lst_003', owner_id:'usr_landlord_002', title:'5-Bed Detached House, Magodo GRA', description:'Grand 5-bedroom detached house. Garden, boys quarters.', listing_type:'sale', property_type:'house', address:'7 Shangisha Road, Magodo Phase 2', area:'Magodo Phase 2', price:65000000, price_period:'total', bedrooms:5, bathrooms:4, size_sqm:420, furnished:false, status:'active', verification_tier:'certified', amenities:JSON.stringify(['Generator','Borehole','Security','Garden','BQ']) },
    { id:'lst_004', owner_id:'usr_landlord_002', title:'2-Bed Flat, Surulere', description:'Clean 2-bedroom flat. Close to National Stadium.', listing_type:'rent', property_type:'apartment', address:'18 Bode Thomas Street, Surulere', area:'Surulere', price:480000, price_period:'year', caution_deposit:480000, bedrooms:2, bathrooms:2, size_sqm:110, furnished:false, status:'active', verification_tier:'verified', amenities:JSON.stringify(['Security','Borehole','Generator']) },
  ];

  for (const l of listings) {
    await query(`
      INSERT INTO listings (id,owner_id,title,description,listing_type,property_type,address,area,price,price_period,caution_deposit,bedrooms,bathrooms,size_sqm,furnished,status,verification_tier,amenities)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18)
      ON CONFLICT (id) DO NOTHING
    `, [l.id,l.owner_id,l.title,l.description,l.listing_type,l.property_type,l.address,l.area,
        l.price,l.price_period,l.caution_deposit||null,l.bedrooms||null,l.bathrooms||null,
        l.size_sqm||null,l.furnished||false,l.status,l.verification_tier,l.amenities||null]);
  }
  console.log(`  ✓ ${listings.length} listings`);

  // Verification records
  for (const l of listings) {
    await query(`
      INSERT INTO verifications (id,listing_id,owner_id,l1_status,l2_status,l3_status,l4_status,l5_status,current_layer,overall_status)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
      ON CONFLICT (listing_id) DO NOTHING
    `, [uuidv4(), l.id, l.owner_id,
        'approved','approved',
        l.verification_tier==='certified'?'approved':'pending',
        l.verification_tier==='certified'?'completed':'pending',
        l.verification_tier==='certified'?'approved':'pending',
        l.verification_tier==='certified'?5:2,
        l.verification_tier==='certified'?'certified':'in_progress']);
  }
  console.log('  ✓ verification records');

  // Agreement
  await query(`
    INSERT INTO agreements (id,listing_id,landlord_id,tenant_id,agent_id,type,status,start_date,end_date,rent_amount,rent_period,caution_deposit,landlord_signed_at,tenant_signed_at)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,NOW(),NOW())
    ON CONFLICT (id) DO NOTHING
  `, ['agr_001','lst_004','usr_landlord_002','usr_tenant_001','usr_agent_001','rental','fully_signed','2026-01-01','2026-12-31',480000,'yearly',480000]);
  console.log('  ✓ agreement');

  await query(`
    INSERT INTO rent_schedule (id,agreement_id,due_date,amount,status) VALUES ($1,'agr_001','2026-01-01',480000,'paid')
    ON CONFLICT (id) DO NOTHING
  `, [uuidv4()]);

  await query(`
    INSERT INTO transactions (id,reference,listing_id,payer_id,payee_id,agent_id,type,status,amount,platform_fee,agent_commission,payee_amount,description)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
    ON CONFLICT (id) DO NOTHING
  `, ['txn_001','PROPATI-2026-001','lst_004','usr_tenant_001','usr_landlord_002','usr_agent_001','rent','released',480000,48000,48000,384000,'Annual rent - Surulere flat']);
  console.log('  ✓ transaction');

  console.log('\n🎉 Seed complete!\n');
  console.log('  Admin:    admin@propati.ng   / Admin1234!');
  console.log('  Landlord: chidi@propati.ng   / Chidi1234!');
  console.log('  Tenant:   adaeze@propati.ng  / Adaeze1234!');
  console.log('  Agent:    akin@propati.ng    / Akin1234!');
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });
