// src/index.js — PROPATI Backend v2 — Production-hardened entry point
require('dotenv').config();
const express    = require('express');
const cors       = require('cors');
const helmet     = require('helmet');
const morgan     = require('morgan');
const rateLimit  = require('express-rate-limit');
const slowDown   = require('express-slow-down');
const compression = require('compression');
const mongoSanitize = require('express-mongo-sanitize');
const hpp        = require('hpp');
const path       = require('path');
const logger     = require('./services/logger');
const { migrate } = require('./db/migrate');
const { checkConnection } = require('./db');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Trust proxy (required for Railway/Render/Nginx) ────────
app.set('trust proxy', 1);

// ── Database startup ───────────────────────────────────────
(async () => {
  try {
    await migrate();
    logger.info('✅ Database ready');
  } catch (err) {
    logger.error('❌ Database startup failed', { error: err.message });
    if (process.env.NODE_ENV === 'production') process.exit(1);
  }
})();

// ════════════════════════════════════════════════════════════
// SECURITY MIDDLEWARE — order matters
// ════════════════════════════════════════════════════════════

// 1. Helmet — sets ~14 security-related HTTP headers
app.use(helmet({
  // Content Security Policy
  contentSecurityPolicy: {
    directives: {
      defaultSrc:  ["'self'"],
      scriptSrc:   ["'self'"],
      styleSrc:    ["'self'", "'unsafe-inline'"],
      imgSrc:      ["'self'", 'data:', 'https://res.cloudinary.com'],
      connectSrc:  ["'self'"],
      frameAncestors: ["'none'"],
    },
  },
  // Allow Cloudinary images cross-origin
  crossOriginResourcePolicy: { policy: 'cross-origin' },
  // Prevent MIME sniffing
  noSniff: true,
  // Deny iframe embedding
  frameguard: { action: 'deny' },
  // Force HTTPS in production
  hsts: process.env.NODE_ENV === 'production'
    ? { maxAge: 31536000, includeSubDomains: true, preload: true }
    : false,
}));

// 2. CORS — only allow known frontend
const allowedOrigins = [
  process.env.FRONTEND_URL,
  'http://localhost:5500',
  'http://localhost:3000',
  'http://127.0.0.1:5500',
].filter(Boolean);

app.use(cors({
  origin: (origin, cb) => {
    // Allow requests with no origin (mobile apps, Postman)
    if (!origin) return cb(null, true);
    if (allowedOrigins.includes(origin) || process.env.NODE_ENV !== 'production') {
      cb(null, true);
    } else {
      logger.security('CORS blocked', origin);
      cb(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  methods: ['GET','POST','PUT','PATCH','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization','X-Request-ID'],
}));

// 3. Rate limiting — tiered by endpoint sensitivity
const globalLimit = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_MAX) || 300,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many requests. Try again in 15 minutes.' },
  handler: (req, res, next, options) => {
    logger.security('Rate limit hit', req.ip, { path: req.path });
    res.status(429).json(options.message);
  },
});

// Aggressive limit for auth endpoints (prevent brute force)
const authLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: parseInt(process.env.AUTH_RATE_LIMIT_MAX) || 10,
  skipSuccessfulRequests: true,  // only count failed attempts
  message: { success: false, error: 'Too many failed attempts. Account locked for 15 minutes.' },
  handler: (req, res, next, options) => {
    logger.security('Auth rate limit hit', req.ip, { path: req.path, email: req.body?.email });
    res.status(429).json(options.message);
  },
});

// Slow down repeated requests (progressive delay before hard block)
const speedLimiter = slowDown({
  windowMs: 15 * 60 * 1000,
  delayAfter: 50,      // start slowing after 50 requests
  delayMs: (used) => (used - 50) * 100, // +100ms per request over limit
});

app.use('/api', globalLimit);
app.use('/api', speedLimiter);
app.use('/api/auth/login',  authLimit);
app.use('/api/auth/signup', authLimit);

// 4. HTTP Parameter Pollution protection
app.use(hpp({
  whitelist: ['type', 'area', 'state', 'sort'] // allow array for these filters
}));

// 5. NoSQL/XSS sanitisation (strip $ and < from inputs)
app.use(mongoSanitize());

// ════════════════════════════════════════════════════════════
// PERFORMANCE MIDDLEWARE
// ════════════════════════════════════════════════════════════

// Gzip compression — reduces response size ~70%
app.use(compression());

// ── Body parsing ───────────────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ── Request ID (for log correlation) ──────────────────────
app.use((req, res, next) => {
  req.id = req.headers['x-request-id'] || require('uuid').v4().slice(0, 8);
  res.setHeader('X-Request-ID', req.id);
  next();
});

// ── HTTP request logging via Winston ──────────────────────
app.use(morgan(
  process.env.NODE_ENV === 'production'
    ? ':remote-addr :method :url :status :res[content-length] - :response-time ms'
    : 'dev',
  { stream: logger.stream }
));

// ── Serve Cloudinary URLs (no local /uploads in production) ─
if (process.env.NODE_ENV !== 'production') {
  app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));
}

// ════════════════════════════════════════════════════════════
// HEALTH CHECK (unauthenticated — used by Railway/Render)
// ════════════════════════════════════════════════════════════
app.get('/health', async (req, res) => {
  const dbOk = await checkConnection().catch(() => false);
  const status = dbOk ? 'healthy' : 'degraded';
  res.status(dbOk ? 200 : 503).json({
    status,
    service:     'PROPATI API',
    version:     '2.0.0',
    environment: process.env.NODE_ENV || 'development',
    database:    dbOk ? 'connected' : 'disconnected',
    storage:     process.env.CLOUDINARY_CLOUD_NAME ? 'cloudinary' : 'local',
    timestamp:   new Date().toISOString(),
  });
});

// ════════════════════════════════════════════════════════════
// API ROUTES
// ════════════════════════════════════════════════════════════
app.use('/api/auth',         require('./routes/auth'));
app.use('/api/listings',     require('./routes/listings'));
app.use('/api/verification', require('./routes/verification'));
app.use('/api/payments',     require('./routes/payments'));
app.use('/api/agreements',   require('./routes/agreements'));
app.use('/api/users',        require('./routes/users'));

// ── 404 ────────────────────────────────────────────────────
app.use((req, res) => {
  logger.debug('404', { method: req.method, path: req.path, ip: req.ip });
  res.status(404).json({ success: false, error: `Route ${req.method} ${req.path} not found` });
});

// ── Global error handler ───────────────────────────────────
app.use((err, req, res, next) => {
  // Log full error internally
  logger.error('Unhandled error', {
    requestId: req.id,
    method: req.method,
    path: req.path,
    error: err.message,
    stack: err.stack,
  });

  if (err.message === 'Not allowed by CORS') {
    return res.status(403).json({ success: false, error: 'CORS: Origin not allowed' });
  }
  if (err.name === 'MulterError') {
    if (err.code === 'LIMIT_FILE_SIZE')
      return res.status(413).json({ success: false, error: `File too large. Max ${process.env.MAX_FILE_SIZE_MB || 10}MB` });
    return res.status(400).json({ success: false, error: err.message });
  }

  // Never leak stack traces in production
  res.status(err.status || 500).json({
    success: false,
    error: process.env.NODE_ENV === 'production'
      ? 'Something went wrong. Our team has been notified.'
      : err.message,
    requestId: req.id,
  });
});

// ── Start ──────────────────────────────────────────────────
app.listen(PORT, () => {
  logger.info(`🚀 PROPATI API v2 started`, {
    port: PORT,
    env: process.env.NODE_ENV || 'development',
    db: process.env.DATABASE_URL ? 'PostgreSQL (cloud)' : 'PostgreSQL (local)',
    storage: process.env.CLOUDINARY_CLOUD_NAME ? 'Cloudinary' : 'Local disk (dev)',
  });
});

// ── Graceful shutdown ──────────────────────────────────────
process.on('SIGTERM', () => {
  logger.info('SIGTERM received. Shutting down gracefully...');
  process.exit(0);
});
process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled promise rejection', { reason: String(reason) });
});
process.on('uncaughtException', (err) => {
  logger.error('Uncaught exception', { error: err.message, stack: err.stack });
  process.exit(1);
});

module.exports = app;
