// src/routes/agreements.js — Agreements & Rent Collection
const router = require('express').Router();
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const { getDb } = require('../db');
const { authenticate, requireRole } = require('../middleware/auth');
const { ok, fail, generateRef } = require('../utils');
const { createNotification, notifyRentDue } = require('../services/notifications');
const paystack = require('../services/paystack');

// ── POST /api/agreements ───────────────────────────────────
// Landlord creates a lease agreement
router.post('/', authenticate, requireRole('landlord','agent','admin'), [
  body('listing_id').notEmpty(),
  body('tenant_id').notEmpty(),
  body('type').isIn(['rental','sale','short_let','share']),
  body('start_date').isISO8601(),
  body('end_date').optional().isISO8601(),
  body('rent_amount').isFloat({ min: 1 }),
  body('rent_period').isIn(['monthly','yearly']),
  body('caution_deposit').optional().isFloat({ min: 0 }),
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return fail(res, 'Validation failed', 422, errors.array());

  const db = getDb();
  const {
    listing_id, tenant_id, type, start_date, end_date,
    rent_amount, rent_period, caution_deposit, service_charge,
    notice_period_days, special_clauses, agent_id
  } = req.body;

  const listing = db.prepare('SELECT * FROM listings WHERE id = ?').get(listing_id);
  if (!listing) return fail(res, 'Listing not found', 404);

  const tenant = db.prepare("SELECT * FROM users WHERE id = ? AND role = 'tenant'").get(tenant_id);
  if (!tenant) return fail(res, 'Tenant not found', 404);

  const id = 'agr_' + uuidv4().replace(/-/g, '').slice(0, 12);

  db.prepare(`
    INSERT INTO agreements (
      id, listing_id, landlord_id, tenant_id, agent_id, type, status,
      start_date, end_date, rent_amount, rent_period, caution_deposit,
      service_charge, notice_period_days, special_clauses
    ) VALUES (?, ?, ?, ?, ?, ?, 'draft', ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id, listing_id, req.user.id, tenant_id, agent_id || listing.agent_id || null,
    type, start_date, end_date || null, rent_amount, rent_period,
    caution_deposit || 0, service_charge || 0,
    notice_period_days || 30, special_clauses || null
  );

  // Generate rent schedule
  if (type === 'rental' && end_date) {
    _generateRentSchedule(db, id, start_date, end_date, rent_amount, rent_period);
  }

  // Notify tenant
  createNotification(tenant_id, 'agreement_created', 'Lease Agreement Ready to Sign',
    `Your landlord has created a ${type} agreement for ${listing.title}. Please review and sign.`,
    { agreement_id: id });

  const agreement = db.prepare('SELECT * FROM agreements WHERE id = ?').get(id);
  return ok(res, { agreement }, 201);
});

function _generateRentSchedule(db, agreementId, startDate, endDate, amount, period) {
  const start = new Date(startDate);
  const end = new Date(endDate);
  const insert = db.prepare('INSERT INTO rent_schedule (id, agreement_id, due_date, amount, status) VALUES (?, ?, ?, ?, ?)');

  let current = new Date(start);
  const monthsToAdd = period === 'monthly' ? 1 : 12;

  while (current <= end) {
    insert.run(uuidv4(), agreementId, current.toISOString().split('T')[0], amount, 'upcoming');
    current.setMonth(current.getMonth() + monthsToAdd);
  }
}

// ── GET /api/agreements/:id ────────────────────────────────
router.get('/:id', authenticate, (req, res) => {
  const db = getDb();
  const agr = db.prepare(`
    SELECT a.*,
      l.title as listing_title, l.address, l.area,
      u1.full_name as landlord_name, u1.email as landlord_email, u1.phone as landlord_phone,
      u2.full_name as tenant_name, u2.email as tenant_email, u2.phone as tenant_phone,
      u3.full_name as agent_name
    FROM agreements a
    JOIN listings l ON a.listing_id = l.id
    JOIN users u1 ON a.landlord_id = u1.id
    JOIN users u2 ON a.tenant_id = u2.id
    LEFT JOIN users u3 ON a.agent_id = u3.id
    WHERE a.id = ?
  `).get(req.params.id);

  if (!agr) return fail(res, 'Agreement not found', 404);

  const isParty = [agr.landlord_id, agr.tenant_id, agr.agent_id].includes(req.user.id);
  if (!isParty && req.user.role !== 'admin') return fail(res, 'Not authorised', 403);

  const schedule = db.prepare('SELECT * FROM rent_schedule WHERE agreement_id = ? ORDER BY due_date').all(agr.id);
  return ok(res, { agreement: { ...agr, rent_schedule: schedule } });
});

// ── GET /api/agreements/my ─────────────────────────────────
router.get('/user/my', authenticate, (req, res) => {
  const db = getDb();
  let query, params;

  if (req.user.role === 'landlord') {
    query = 'SELECT a.*, l.title as listing_title, u.full_name as tenant_name FROM agreements a JOIN listings l ON a.listing_id = l.id JOIN users u ON a.tenant_id = u.id WHERE a.landlord_id = ? ORDER BY a.created_at DESC';
    params = [req.user.id];
  } else if (req.user.role === 'tenant') {
    query = 'SELECT a.*, l.title as listing_title, u.full_name as landlord_name FROM agreements a JOIN listings l ON a.listing_id = l.id JOIN users u ON a.landlord_id = u.id WHERE a.tenant_id = ? ORDER BY a.created_at DESC';
    params = [req.user.id];
  } else {
    query = 'SELECT a.*, l.title as listing_title FROM agreements a JOIN listings l ON a.listing_id = l.id WHERE a.agent_id = ? ORDER BY a.created_at DESC';
    params = [req.user.id];
  }

  return ok(res, { agreements: db.prepare(query).all(...params) });
});

// ── POST /api/agreements/:id/sign ─────────────────────────
// Landlord or tenant signs the agreement (e-signature)
router.post('/:id/sign', authenticate, (req, res) => {
  const db = getDb();
  const agr = db.prepare('SELECT * FROM agreements WHERE id = ?').get(req.params.id);
  if (!agr) return fail(res, 'Agreement not found', 404);
  if (agr.status === 'fully_signed') return fail(res, 'Agreement already fully signed', 409);
  if (agr.status === 'terminated') return fail(res, 'Agreement has been terminated', 410);

  const ip = req.ip || req.connection.remoteAddress;
  let newStatus = agr.status;

  if (req.user.id === agr.landlord_id && !agr.landlord_signed_at) {
    db.prepare("UPDATE agreements SET landlord_signed_at = datetime('now'), landlord_ip = ?, status = 'landlord_signed', updated_at = datetime('now') WHERE id = ?")
      .run(ip, agr.id);
    newStatus = 'landlord_signed';
    createNotification(agr.tenant_id, 'agreement_signed', 'Landlord has signed the agreement',
      'Your landlord has signed the agreement. Please sign to finalise the lease.',
      { agreement_id: agr.id });
  } else if (req.user.id === agr.tenant_id && !agr.tenant_signed_at) {
    db.prepare("UPDATE agreements SET tenant_signed_at = datetime('now'), tenant_ip = ?, status = 'tenant_signed', updated_at = datetime('now') WHERE id = ?")
      .run(ip, agr.id);
    newStatus = 'tenant_signed';
  } else {
    return fail(res, 'You have already signed or are not a party to this agreement', 409);
  }

  // If both signed, mark fully signed
  const updated = db.prepare('SELECT * FROM agreements WHERE id = ?').get(agr.id);
  if (updated.landlord_signed_at && updated.tenant_signed_at) {
    db.prepare("UPDATE agreements SET status = 'fully_signed', updated_at = datetime('now') WHERE id = ?").run(agr.id);
    newStatus = 'fully_signed';

    // Mark listing as rented if rental
    if (agr.type === 'rental') {
      db.prepare("UPDATE listings SET status = 'rented' WHERE id = ?").run(agr.listing_id);
    }

    createNotification(agr.landlord_id, 'agreement_complete', '🎉 Agreement fully signed!',
      'Both parties have signed the agreement. The lease is now active.', { agreement_id: agr.id });
    createNotification(agr.tenant_id, 'agreement_complete', '🎉 Agreement fully signed!',
      'Your tenancy agreement is now active. Welcome to your new home!', { agreement_id: agr.id });
  }

  return ok(res, { message: `Agreement ${newStatus.replace('_', ' ')}`, status: newStatus });
});

// ── GET /api/agreements/:id/schedule ──────────────────────
router.get('/:id/schedule', authenticate, (req, res) => {
  const db = getDb();
  const agr = db.prepare('SELECT * FROM agreements WHERE id = ?').get(req.params.id);
  if (!agr) return fail(res, 'Not found', 404);
  const isParty = [agr.landlord_id, agr.tenant_id].includes(req.user.id);
  if (!isParty && req.user.role !== 'admin') return fail(res, 'Not authorised', 403);

  const schedule = db.prepare('SELECT * FROM rent_schedule WHERE agreement_id = ? ORDER BY due_date').all(agr.id);
  const overdue = schedule.filter(s => s.status === 'upcoming' && new Date(s.due_date) < new Date());

  // Mark overdue
  if (overdue.length > 0) {
    db.prepare(`UPDATE rent_schedule SET status = 'overdue' WHERE agreement_id = ? AND status = 'upcoming' AND due_date < date('now')`)
      .run(agr.id);
  }

  return ok(res, { schedule: db.prepare('SELECT * FROM rent_schedule WHERE agreement_id = ? ORDER BY due_date').all(agr.id) });
});

// ── POST /api/agreements/:id/pay-rent ─────────────────────
// Tenant initiates rent payment for a specific schedule entry
router.post('/:id/pay-rent', authenticate, requireRole('tenant'), [
  body('schedule_id').notEmpty(),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return fail(res, 'Validation failed', 422, errors.array());

  const db = getDb();
  const agr = db.prepare('SELECT * FROM agreements WHERE id = ? AND tenant_id = ?').get(req.params.id, req.user.id);
  if (!agr) return fail(res, 'Agreement not found or not your tenancy', 404);
  if (agr.status !== 'fully_signed') return fail(res, 'Agreement must be fully signed', 400);

  const entry = db.prepare("SELECT * FROM rent_schedule WHERE id = ? AND agreement_id = ? AND status != 'paid'").get(req.body.schedule_id, agr.id);
  if (!entry) return fail(res, 'Rent entry not found or already paid', 404);

  const reference = generateRef();
  const result = await paystack.initializePayment({
    email: req.user.email,
    amount: entry.amount,
    reference,
    metadata: { agreement_id: agr.id, schedule_id: entry.id, type: 'rent' }
  });

  if (!result.success) return fail(res, 'Payment initiation failed', 502);

  return ok(res, {
    payment_url: result.data.authorization_url,
    reference,
    amount: entry.amount,
    due_date: entry.due_date
  });
});

// ── POST /api/agreements/:id/terminate ────────────────────
router.post('/:id/terminate', authenticate, [
  body('reason').trim().isLength({ min: 10 }),
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return fail(res, 'Validation failed', 422, errors.array());

  const db = getDb();
  const agr = db.prepare('SELECT * FROM agreements WHERE id = ?').get(req.params.id);
  if (!agr) return fail(res, 'Not found', 404);
  const isParty = [agr.landlord_id, agr.tenant_id].includes(req.user.id);
  if (!isParty && req.user.role !== 'admin') return fail(res, 'Not authorised', 403);

  db.prepare("UPDATE agreements SET status = 'terminated', special_clauses = COALESCE(special_clauses,'') || '\n\nTERMINATION: ' || ?, updated_at = datetime('now') WHERE id = ?")
    .run(`Terminated on ${new Date().toISOString()} by ${req.user.full_name}. Reason: ${req.body.reason}`, agr.id);

  const other = req.user.id === agr.landlord_id ? agr.tenant_id : agr.landlord_id;
  createNotification(other, 'agreement_terminated', 'Agreement Terminated', `The lease has been terminated. Reason: ${req.body.reason}`, { agreement_id: agr.id });

  return ok(res, { message: 'Agreement terminated' });
});

// ── GET /api/agreements/:id/disputes ──────────────────────
router.get('/:id/disputes', authenticate, (req, res) => {
  const db = getDb();
  const agr = db.prepare('SELECT * FROM agreements WHERE id = ?').get(req.params.id);
  if (!agr) return fail(res, 'Not found', 404);
  const isParty = [agr.landlord_id, agr.tenant_id].includes(req.user.id);
  if (!isParty && req.user.role !== 'admin') return fail(res, 'Not authorised', 403);

  const disputes = db.prepare('SELECT * FROM disputes WHERE agreement_id = ? ORDER BY created_at DESC').all(agr.id);
  return ok(res, { disputes });
});

module.exports = router;
