// src/routes/payments.js — Payments & Escrow
const router = require('express').Router();
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const { getDb } = require('../db');
const { authenticate, requireRole } = require('../middleware/auth');
const { computeFees, generateRef, ok, fail } = require('../utils');
const paystack = require('../services/paystack');
const { notifyPaymentReceived, notifyEscrowReleased, createNotification } = require('../services/notifications');

// ── POST /api/payments/initiate ────────────────────────────
// Tenant/buyer initiates payment → goes into escrow
router.post('/initiate', authenticate, [
  body('listing_id').notEmpty(),
  body('type').isIn(['rent','sale','short_let','caution','service_charge']),
  body('amount').isFloat({ min: 100 }),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return fail(res, 'Validation failed', 422, errors.array());

  const db = getDb();
  const { listing_id, type, amount } = req.body;

  const listing = db.prepare("SELECT * FROM listings WHERE id = ? AND status = 'active'").get(listing_id);
  if (!listing) return fail(res, 'Listing not found or not active', 404);

  const landlord = db.prepare('SELECT * FROM users WHERE id = ?').get(listing.owner_id);
  if (!landlord) return fail(res, 'Landlord not found', 404);

  const { platformFee, agentCommission, payeeAmount } = computeFees(type, amount);

  const txnId = 'txn_' + uuidv4().replace(/-/g, '').slice(0, 12);
  const reference = generateRef();

  // Escrow release: 7 days after payment for rent, 30 days for sale
  const releaseAfterDays = type === 'sale' ? 30 : 7;
  const escrowRelease = new Date(Date.now() + releaseAfterDays * 24 * 60 * 60 * 1000).toISOString();

  // Create pending transaction
  db.prepare(`
    INSERT INTO transactions (id, reference, listing_id, payer_id, payee_id, agent_id, type, status,
      amount, platform_fee, agent_commission, payee_amount, escrow_release_date, description)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?, ?, ?)
  `).run(
    txnId, reference, listing_id, req.user.id, listing.owner_id,
    listing.agent_id || null, type, amount, platformFee, agentCommission,
    payeeAmount, escrowRelease,
    `${type} payment for ${listing.title}`
  );

  // Initiate Paystack payment
  const result = await paystack.initializePayment({
    email: req.user.email,
    amount,
    reference,
    metadata: { txn_id: txnId, listing_id, type, user_id: req.user.id }
  });

  if (!result.success) {
    db.prepare("UPDATE transactions SET status = 'failed' WHERE id = ?").run(txnId);
    return fail(res, 'Payment initiation failed: ' + (result.error || 'Unknown error'), 502);
  }

  return ok(res, {
    transaction_id: txnId,
    reference,
    payment_url: result.data.authorization_url,
    amount,
    platform_fee: platformFee,
    escrow_release_date: escrowRelease,
    message: `Payment initiated. Funds will be held in escrow until ${releaseAfterDays} days after confirmation.`
  }, 201);
});

// ── POST /api/payments/verify/:reference ──────────────────
// Called after Paystack redirect / webhook
router.post('/verify/:reference', authenticate, async (req, res) => {
  const db = getDb();
  const txn = db.prepare('SELECT * FROM transactions WHERE reference = ?').get(req.params.reference);
  if (!txn) return fail(res, 'Transaction not found', 404);
  if (txn.payer_id !== req.user.id && req.user.role !== 'admin') return fail(res, 'Not authorised', 403);
  if (txn.status === 'in_escrow' || txn.status === 'released') return ok(res, { transaction: txn, message: 'Already verified' });

  const result = await paystack.verifyPayment(req.params.reference);
  if (!result.success) {
    db.prepare("UPDATE transactions SET status = 'failed' WHERE id = ?").run(txn.id);
    return fail(res, 'Payment not successful on Paystack', 400);
  }

  db.prepare(`
    UPDATE transactions SET status = 'in_escrow', paystack_txn_id = ?, updated_at = datetime('now')
    WHERE id = ?
  `).run(result.data.reference, txn.id);

  // Notify landlord
  const landlord = db.prepare('SELECT * FROM users WHERE id = ?').get(txn.payee_id);
  const listing = db.prepare('SELECT title FROM listings WHERE id = ?').get(txn.listing_id);
  await notifyPaymentReceived(landlord, txn.payee_amount, listing?.title);

  return ok(res, {
    transaction: db.prepare('SELECT * FROM transactions WHERE id = ?').get(txn.id),
    message: `Payment of ₦${txn.amount.toLocaleString()} confirmed and held in escrow until ${txn.escrow_release_date}`
  });
});

// ── POST /api/payments/webhook ─────────────────────────────
// Paystack webhook handler (no auth — validated by signature)
router.post('/webhook', (req, res) => {
  const sig = req.headers['x-paystack-signature'];
  if (!paystack.verifyWebhook(req.body, sig)) {
    return res.status(400).send('Invalid signature');
  }
  const event = req.body;
  if (event.event === 'charge.success') {
    const { reference } = event.data;
    const db = getDb();
    const txn = db.prepare("SELECT * FROM transactions WHERE reference = ? AND status = 'pending'").get(reference);
    if (txn) {
      db.prepare("UPDATE transactions SET status = 'in_escrow', updated_at = datetime('now') WHERE id = ?").run(txn.id);
    }
  }
  res.sendStatus(200);
});

// ── POST /api/payments/:txnId/release ─────────────────────
// Admin or auto-release: move funds from escrow to landlord
router.post('/:txnId/release', authenticate, requireRole('admin'), async (req, res) => {
  const db = getDb();
  const txn = db.prepare("SELECT * FROM transactions WHERE id = ? AND status = 'in_escrow'").get(req.params.txnId);
  if (!txn) return fail(res, 'Transaction not in escrow or not found', 404);

  db.prepare(`
    UPDATE transactions SET status = 'released', escrow_released_at = datetime('now'),
      escrow_released_by = ?, updated_at = datetime('now')
    WHERE id = ?
  `).run(req.user.id, txn.id);

  // In production: call paystack.initiateTransfer() to pay landlord
  const landlord = db.prepare('SELECT * FROM users WHERE id = ?').get(txn.payee_id);
  await notifyEscrowReleased(landlord, txn.payee_amount);

  return ok(res, {
    message: `₦${txn.payee_amount.toLocaleString()} released from escrow to ${landlord.full_name}`,
    transaction: db.prepare('SELECT * FROM transactions WHERE id = ?').get(txn.id)
  });
});

// ── GET /api/payments/my-transactions ─────────────────────
router.get('/my-transactions', authenticate, (req, res) => {
  const db = getDb();
  const txns = db.prepare(`
    SELECT t.*, l.title as listing_title, l.area
    FROM transactions t
    LEFT JOIN listings l ON t.listing_id = l.id
    WHERE t.payer_id = ? OR t.payee_id = ?
    ORDER BY t.created_at DESC
    LIMIT 50
  `).all(req.user.id, req.user.id);
  return ok(res, { transactions: txns });
});

// ── GET /api/payments/:txnId ───────────────────────────────
router.get('/:txnId', authenticate, (req, res) => {
  const db = getDb();
  const txn = db.prepare('SELECT t.*, l.title as listing_title FROM transactions t LEFT JOIN listings l ON t.listing_id = l.id WHERE t.id = ?').get(req.params.txnId);
  if (!txn) return fail(res, 'Transaction not found', 404);
  if (txn.payer_id !== req.user.id && txn.payee_id !== req.user.id && req.user.role !== 'admin') {
    return fail(res, 'Not authorised', 403);
  }
  return ok(res, { transaction: txn });
});

// ── POST /api/payments/:txnId/dispute ─────────────────────
router.post('/:txnId/dispute', authenticate, [
  body('reason').trim().isLength({ min: 20 }),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return fail(res, 'Validation failed', 422, errors.array());

  const db = getDb();
  const txn = db.prepare('SELECT * FROM transactions WHERE id = ?').get(req.params.txnId);
  if (!txn) return fail(res, 'Transaction not found', 404);
  if (txn.payer_id !== req.user.id && txn.payee_id !== req.user.id) return fail(res, 'Not authorised', 403);

  const disputeId = 'dsp_' + uuidv4().slice(0, 12);
  const against = txn.payer_id === req.user.id ? txn.payee_id : txn.payer_id;

  db.prepare(`
    INSERT INTO disputes (id, transaction_id, raised_by, against, type, status, severity, description, amount_disputed)
    VALUES (?, ?, ?, ?, 'payment_not_received', 'open', 2, ?, ?)
  `).run(disputeId, txn.id, req.user.id, against, req.body.reason, txn.amount);

  // Hold escrow during dispute
  if (txn.status === 'in_escrow') {
    db.prepare("UPDATE transactions SET status = 'disputed', updated_at = datetime('now') WHERE id = ?").run(txn.id);
  }

  createNotification(against, 'dispute_raised', 'Payment Dispute Raised', 'A dispute has been raised on a transaction. PROPATI team will investigate.', { dispute_id: disputeId });

  return ok(res, { message: 'Dispute raised. Escrow held. Our team will investigate within 48 hours.', dispute_id: disputeId }, 201);
});

module.exports = router;
