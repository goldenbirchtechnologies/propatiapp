// src/routes/verification.js — 5-Layer Verification Engine
const router = require('express').Router();
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const { getDb } = require('../db');
const { authenticate, requireRole } = require('../middleware/auth');
const { uploadDocument, uploadVideo } = require('../middleware/upload');
const { generateQRCode, ok, fail } = require('../utils');
const { notifyVerificationUpdate } = require('../services/notifications');

// Helper — get verification + listing + owner
function getVerif(listingId, userId, isAdmin) {
  const db = getDb();
  const v = db.prepare('SELECT v.*, l.title, l.owner_id FROM verifications v JOIN listings l ON v.listing_id = l.id WHERE v.listing_id = ?').get(listingId);
  if (!v) return { error: 'Verification record not found' };
  if (!isAdmin && v.owner_id !== userId) return { error: 'Not authorised' };
  return { verif: v };
}

// ── GET /api/verification/:listingId ──────────────────────
router.get('/:listingId', authenticate, (req, res) => {
  const db = getDb();
  const verif = db.prepare('SELECT * FROM verifications WHERE listing_id = ?').get(req.params.listingId);
  if (!verif) return fail(res, 'No verification record for this listing', 404);
  return ok(res, { verification: verif });
});

// ── LAYER 1: Document Upload ───────────────────────────────
// POST /api/verification/:listingId/layer1
router.post('/:listingId/layer1', authenticate,
  uploadDocument.fields([
    { name: 'coo', maxCount: 1 },
    { name: 'title_deed', maxCount: 1 },
    { name: 'survey', maxCount: 1 },
    { name: 'deed', maxCount: 1 },
    { name: 'governors_consent', maxCount: 1 },
  ]),
  async (req, res) => {
    const db = getDb();
    const { error, verif } = getVerif(req.params.listingId, req.user.id, false);
    if (error) return fail(res, error, 403);
    if (verif.l1_status === 'approved') return fail(res, 'Layer 1 already approved', 409);

    const files = req.files || {};
    if (!files.coo && !files.title_deed) {
      return fail(res, 'At least Certificate of Occupancy or Title Deed is required', 400);
    }

    const updates = { l1_status: 'submitted', l1_submitted_at: new Date().toISOString() };
    if (files.coo)                updates.l1_doc_coo    = `/uploads/documents/${files.coo[0].filename}`;
    if (files.title_deed)         updates.l1_doc_title  = `/uploads/documents/${files.title_deed[0].filename}`;
    if (files.survey)             updates.l1_doc_survey = `/uploads/documents/${files.survey[0].filename}`;
    if (files.deed)               updates.l1_doc_deed   = `/uploads/documents/${files.deed[0].filename}`;
    if (files.governors_consent)  updates.l1_doc_govcon = `/uploads/documents/${files.governors_consent[0].filename}`;

    const sets = Object.entries(updates).map(([k]) => `${k} = ?`).join(', ');
    db.prepare(`UPDATE verifications SET ${sets}, updated_at = datetime('now') WHERE listing_id = ?`)
      .run(...Object.values(updates), req.params.listingId);

    return ok(res, { message: 'Layer 1 documents submitted. Our team will review within 24 hours.' });
  }
);

// ── LAYER 2: Identity Match ────────────────────────────────
// POST /api/verification/:listingId/layer2
router.post('/:listingId/layer2', authenticate,
  uploadDocument.single('id_document'),
  [
    body('id_type').isIn(['nin','passport','drivers_licence']),
    body('id_number').notEmpty(),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return fail(res, 'Validation failed', 422, errors.array());

    const db = getDb();
    const { error, verif } = getVerif(req.params.listingId, req.user.id, false);
    if (error) return fail(res, error, 403);
    if (verif.l1_status !== 'approved') return fail(res, 'Complete Layer 1 first', 400);
    if (verif.l2_status === 'approved') return fail(res, 'Layer 2 already approved', 409);

    const { id_type, id_number } = req.body;
    const idDocUrl = req.file ? `/uploads/documents/${req.file.filename}` : null;

    // Check NIN verified on user account
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
    const ninMatch = user.nin_verified === 1 ? 1 : 0;

    db.prepare(`
      UPDATE verifications SET 
        l2_status = 'submitted', l2_id_type = ?, l2_id_number = ?,
        l2_id_doc_url = ?, l2_nin_match = ?, l2_submitted_at = datetime('now'),
        updated_at = datetime('now')
      WHERE listing_id = ?
    `).run(id_type, id_number, idDocUrl, ninMatch, req.params.listingId);

    return ok(res, { message: 'Layer 2 identity submitted for review.' });
  }
);

// ── LAYER 3: QR Code Generation ───────────────────────────
// POST /api/verification/:listingId/layer3/generate-qr
router.post('/:listingId/layer3/generate-qr', authenticate, (req, res) => {
  const db = getDb();
  const { error, verif } = getVerif(req.params.listingId, req.user.id, false);
  if (error) return fail(res, error, 403);
  if (verif.l2_status !== 'approved') return fail(res, 'Complete Layer 2 first', 400);

  const { code, expires } = generateQRCode();

  db.prepare(`
    UPDATE verifications SET l3_status = 'qr_issued', l3_qr_code = ?, l3_qr_expires = ?, updated_at = datetime('now')
    WHERE listing_id = ?
  `).run(code, expires, req.params.listingId);

  return ok(res, {
    message: 'QR code generated. Record a video inside your property showing this code. Valid for 24 hours.',
    qr_code: code,
    expires_at: expires,
    instructions: [
      'Open the PROPATI app and navigate to your property',
      'Display this QR code on your phone screen',
      'Record a 30-60 second video walking through the property while showing the QR code',
      'Upload the video before the QR code expires (24 hours)'
    ]
  });
});

// ── LAYER 3: Video Upload ──────────────────────────────────
// POST /api/verification/:listingId/layer3/upload
router.post('/:listingId/layer3/upload', authenticate, uploadVideo.single('video'), (req, res) => {
  const db = getDb();
  const { error, verif } = getVerif(req.params.listingId, req.user.id, false);
  if (error) return fail(res, error, 403);
  if (verif.l3_status !== 'qr_issued') return fail(res, 'Generate QR code first', 400);
  if (!req.file) return fail(res, 'No video uploaded', 400);

  // Check QR code not expired
  if (new Date(verif.l3_qr_expires) < new Date()) {
    return fail(res, 'QR code has expired. Generate a new one.', 400);
  }

  db.prepare(`
    UPDATE verifications SET
      l3_status = 'submitted', l3_video_url = ?, l3_submitted_at = datetime('now'),
      updated_at = datetime('now')
    WHERE listing_id = ?
  `).run(`/uploads/videos/${req.file.filename}`, req.params.listingId);

  return ok(res, { message: 'Video submitted. Our team will verify within 48 hours.' });
});

// ── ADMIN: Review Layer 1 ──────────────────────────────────
router.post('/:listingId/layer1/review', authenticate, requireRole('admin'), [
  body('decision').isIn(['approved','rejected']),
  body('notes').optional().isString(),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return fail(res, 'Validation failed', 422, errors.array());

  const db = getDb();
  const verif = db.prepare('SELECT v.*, l.title, l.owner_id FROM verifications v JOIN listings l ON v.listing_id = l.id WHERE v.listing_id = ?').get(req.params.listingId);
  if (!verif) return fail(res, 'Not found', 404);

  const { decision, notes } = req.body;
  db.prepare(`
    UPDATE verifications SET l1_status = ?, l1_reviewed_at = datetime('now'),
      l1_reviewer_id = ?, l1_notes = ?, updated_at = datetime('now')
    WHERE listing_id = ?
  `).run(decision, req.user.id, notes || null, req.params.listingId);

  const owner = db.prepare('SELECT * FROM users WHERE id = ?').get(verif.owner_id);
  await notifyVerificationUpdate(owner, verif.title, 1, decision);

  return ok(res, { message: `Layer 1 ${decision}` });
});

// ── ADMIN: Review Layer 2 ──────────────────────────────────
router.post('/:listingId/layer2/review', authenticate, requireRole('admin'), [
  body('decision').isIn(['approved','rejected']),
  body('notes').optional().isString(),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return fail(res, 'Validation failed', 422, errors.array());

  const db = getDb();
  const verif = db.prepare('SELECT v.*, l.title, l.owner_id FROM verifications v JOIN listings l ON v.listing_id = l.id WHERE v.listing_id = ?').get(req.params.listingId);
  if (!verif) return fail(res, 'Not found', 404);
  if (verif.l1_status !== 'approved') return fail(res, 'Layer 1 must be approved first', 400);

  const { decision, notes } = req.body;
  db.prepare(`
    UPDATE verifications SET l2_status = ?, l2_reviewed_at = datetime('now'), l2_notes = ?,
      current_layer = CASE WHEN ? = 'approved' THEN 3 ELSE 2 END, updated_at = datetime('now')
    WHERE listing_id = ?
  `).run(decision, notes || null, decision, req.params.listingId);

  if (decision === 'approved') {
    db.prepare("UPDATE listings SET verification_tier = 'basic' WHERE id = ?").run(req.params.listingId);
  }

  const owner = db.prepare('SELECT * FROM users WHERE id = ?').get(verif.owner_id);
  await notifyVerificationUpdate(owner, verif.title, 2, decision);

  return ok(res, { message: `Layer 2 ${decision}` });
});

// ── ADMIN: Review Layer 3 (QR Video) ─────────────────────
router.post('/:listingId/layer3/review', authenticate, requireRole('admin'), [
  body('decision').isIn(['approved','rejected']),
  body('notes').optional().isString(),
], async (req, res) => {
  const db = getDb();
  const verif = db.prepare('SELECT v.*, l.title, l.owner_id FROM verifications v JOIN listings l ON v.listing_id = l.id WHERE v.listing_id = ?').get(req.params.listingId);
  if (!verif) return fail(res, 'Not found', 404);

  const { decision, notes } = req.body;
  db.prepare(`
    UPDATE verifications SET l3_status = ?, l3_reviewed_at = datetime('now'), l3_reviewer_id = ?,
      l3_notes = ?, current_layer = CASE WHEN ? = 'approved' THEN 4 ELSE 3 END, updated_at = datetime('now')
    WHERE listing_id = ?
  `).run(decision, req.user.id, notes || null, decision, req.params.listingId);

  if (decision === 'approved') {
    db.prepare("UPDATE listings SET verification_tier = 'verified' WHERE id = ?").run(req.params.listingId);
  }

  const owner = db.prepare('SELECT * FROM users WHERE id = ?').get(verif.owner_id);
  await notifyVerificationUpdate(owner, verif.title, 3, decision);

  return ok(res, { message: `Layer 3 ${decision}` });
});

// ── SCHEDULE LAYER 4 AGENT INSPECTION ────────────────────
router.post('/:listingId/layer4/schedule', authenticate, requireRole('admin'), [
  body('agent_id').notEmpty(),
  body('scheduled_at').isISO8601(),
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return fail(res, 'Validation failed', 422, errors.array());

  const db = getDb();
  const { agent_id, scheduled_at } = req.body;

  const agent = db.prepare("SELECT * FROM users WHERE id = ? AND role = 'agent' AND agent_approved = 1").get(agent_id);
  if (!agent) return fail(res, 'Agent not found or not approved', 404);

  db.prepare(`
    UPDATE verifications SET l4_status = 'scheduled', l4_agent_id = ?, l4_scheduled_at = ?,
      current_layer = 4, updated_at = datetime('now')
    WHERE listing_id = ?
  `).run(agent_id, scheduled_at, req.params.listingId);

  return ok(res, { message: `Inspection scheduled for ${scheduled_at} with agent ${agent.full_name}` });
});

// ── COMPLETE LAYER 4 (Agent marks done) ───────────────────
router.post('/:listingId/layer4/complete', authenticate, requireRole('agent', 'admin'),
  uploadDocument.single('report'),
  [body('notes').optional().isString()],
  async (req, res) => {
    const db = getDb();
    const verif = db.prepare('SELECT v.*, l.title, l.owner_id FROM verifications v JOIN listings l ON v.listing_id = l.id WHERE v.listing_id = ?').get(req.params.listingId);
    if (!verif) return fail(res, 'Not found', 404);

    const reportUrl = req.file ? `/uploads/documents/${req.file.filename}` : null;
    db.prepare(`
      UPDATE verifications SET l4_status = 'completed', l4_completed_at = datetime('now'),
        l4_report_url = ?, l4_notes = ?, current_layer = 5, updated_at = datetime('now')
      WHERE listing_id = ?
    `).run(reportUrl, req.body.notes || null, req.params.listingId);

    db.prepare("UPDATE listings SET verification_tier = 'inspected' WHERE id = ?").run(req.params.listingId);

    const owner = db.prepare('SELECT * FROM users WHERE id = ?').get(verif.owner_id);
    await notifyVerificationUpdate(owner, verif.title, 4, 'completed');

    return ok(res, { message: 'Layer 4 inspection completed. Listing promoted to "Inspected" status.' });
  }
);

// ── LAYER 5: Admin Final Certification ───────────────────
router.post('/:listingId/layer5/certify', authenticate, requireRole('admin'), [
  body('decision').isIn(['approved','rejected']),
  body('notes').optional().isString(),
], async (req, res) => {
  const db = getDb();
  const verif = db.prepare('SELECT v.*, l.title, l.owner_id FROM verifications v JOIN listings l ON v.listing_id = l.id WHERE v.listing_id = ?').get(req.params.listingId);
  if (!verif) return fail(res, 'Not found', 404);
  if (verif.l4_status !== 'completed') return fail(res, 'Layer 4 inspection must be completed first', 400);

  const { decision, notes } = req.body;
  db.prepare(`
    UPDATE verifications SET l5_status = ?, l5_certified_at = datetime('now'), l5_admin_id = ?,
      l5_notes = ?, overall_status = CASE WHEN ? = 'approved' THEN 'certified' ELSE 'rejected' END,
      updated_at = datetime('now')
    WHERE listing_id = ?
  `).run(decision, req.user.id, notes || null, decision, req.params.listingId);

  if (decision === 'approved') {
    db.prepare("UPDATE listings SET verification_tier = 'certified' WHERE id = ?").run(req.params.listingId);
  }

  const owner = db.prepare('SELECT * FROM users WHERE id = ?').get(verif.owner_id);
  await notifyVerificationUpdate(owner, verif.title, 5, decision === 'approved' ? 'CERTIFIED ⭐' : 'rejected');

  return ok(res, { message: decision === 'approved' ? '⭐ Listing granted PROPATI Certified status!' : 'Layer 5 rejected' });
});

module.exports = router;
