// src/db/seed.js — Demo data matching the frontend
require('dotenv').config();
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { migrate, getDb } = require('./index');

async function seed() {
  console.log('🌱 Seeding PROPATI database...');
  migrate();
  const db = getDb();

  const hash = (pw) => bcrypt.hashSync(pw, 10);

  // ── USERS ──────────────────────────────
  const users = [
    { id: 'usr_admin_001', email: 'admin@propati.ng', phone: '08000000001', password: hash('Admin1234!'), role: 'admin', full_name: 'Emeka Okafor', nin_verified: 1, id_verified: 1 },
    { id: 'usr_landlord_001', email: 'chidi@propati.ng', phone: '08012345678', password: hash('Chidi1234!'), role: 'landlord', full_name: 'Chidi Okonkwo', nin_verified: 1, id_verified: 1 },
    { id: 'usr_tenant_001', email: 'adaeze@propati.ng', phone: '08087654321', password: hash('Adaeze1234!'), role: 'tenant', full_name: 'Adaeze Obi', nin_verified: 1, id_verified: 1 },
    { id: 'usr_agent_001', email: 'akin@propati.ng', phone: '08011112222', password: hash('Akin1234!'), role: 'agent', full_name: 'Akin Balogun', nin_verified: 1, id_verified: 1, agent_tier: 'senior', agent_approved: 1, agent_bio: 'Senior PROPATI agent. 14 deals closed in March 2026.', agent_areas: JSON.stringify(['Lekki','Victoria Island','Ikoyi']) },
    { id: 'usr_landlord_002', email: 'rita@propati.ng', phone: '08033334444', password: hash('Rita1234!'), role: 'landlord', full_name: 'Rita Sule', nin_verified: 1, id_verified: 1 },
  ];

  const insertUser = db.prepare(`
    INSERT OR IGNORE INTO users (id,email,phone,password,role,full_name,nin_verified,id_verified,agent_tier,agent_approved,agent_bio,agent_areas)
    VALUES (@id,@email,@phone,@password,@role,@full_name,@nin_verified,@id_verified,@agent_tier,@agent_approved,@agent_bio,@agent_areas)
  `);
  users.forEach(u => insertUser.run({
    agent_tier: null, agent_approved: 0, agent_bio: null, agent_areas: null, ...u
  }));
  console.log(`  ✓ ${users.length} users`);

  // ── LISTINGS ──────────────────────────
  const listings = [
    { id: 'lst_001', owner_id: 'usr_landlord_001', title: '4-Bed Duplex, Lekki Phase 1', description: 'Spacious 4-bedroom duplex in the heart of Lekki Phase 1. Fully tiled, fitted kitchen, 24hr security, 3 parking spaces.', listing_type: 'rent', property_type: 'duplex', address: '12 Admiralty Way, Lekki Phase 1', area: 'Lekki Phase 1', state: 'Lagos', price: 800000, price_period: 'year', caution_deposit: 800000, bedrooms: 4, bathrooms: 3, size_sqm: 280, furnished: 0, status: 'active', verification_tier: 'certified', amenities: JSON.stringify(['Generator','Borehole','Security','CCTV','Swimming Pool']) },
    { id: 'lst_002', owner_id: 'usr_landlord_001', title: 'Luxury 3-Bed Apartment, Victoria Island', description: 'Premium serviced apartment on Victoria Island. Stunning ocean views, rooftop pool, concierge service.', listing_type: 'short-let', property_type: 'apartment', address: '45 Adeola Odeku St, Victoria Island', area: 'Victoria Island', state: 'Lagos', price: 85000, price_period: 'night', caution_deposit: 170000, bedrooms: 3, bathrooms: 3, size_sqm: 190, furnished: 1, status: 'active', verification_tier: 'verified', amenities: JSON.stringify(['Pool','Gym','Concierge','Generator','WiFi']) },
    { id: 'lst_003', owner_id: 'usr_landlord_002', title: '5-Bed Detached House, Magodo GRA', description: 'Grand 5-bedroom detached house in the prestigious Magodo GRA Phase 2. Double compound, boys quarters, garden.', listing_type: 'sale', property_type: 'house', address: '7 Shangisha Road, Magodo Phase 2', area: 'Magodo Phase 2', state: 'Lagos', price: 65000000, price_period: 'total', bedrooms: 5, bathrooms: 4, size_sqm: 420, furnished: 0, status: 'active', verification_tier: 'certified', amenities: JSON.stringify(['Generator','Borehole','Security','Garden','BQ']) },
    { id: 'lst_004', owner_id: 'usr_landlord_002', title: '2-Bed Flat, Surulere', description: 'Clean and affordable 2-bedroom flat in a serene Surulere compound. Close to National Stadium.', listing_type: 'rent', property_type: 'apartment', address: '18 Bode Thomas Street, Surulere', area: 'Surulere', state: 'Lagos', price: 480000, price_period: 'year', caution_deposit: 480000, bedrooms: 2, bathrooms: 2, size_sqm: 110, furnished: 0, status: 'active', verification_tier: 'verified', amenities: JSON.stringify(['Security','Borehole','Generator']) },
    { id: 'lst_005', owner_id: 'usr_landlord_001', title: 'Open-plan Office Space, Ikeja GRA', description: 'Modern open-plan office on the ground floor of a commercial complex in Ikeja GRA. Fibre internet included.', listing_type: 'commercial', property_type: 'office', address: '33 Isaac John Street, Ikeja GRA', area: 'Ikeja GRA', state: 'Lagos', price: 4800000, price_period: 'year', bedrooms: null, bathrooms: 4, size_sqm: 340, furnished: 1, status: 'active', verification_tier: 'certified', amenities: JSON.stringify(['Fibre Internet','Generator','AC','Security','Parking']) },
  ];

  const insertListing = db.prepare(`
    INSERT OR IGNORE INTO listings (id,owner_id,title,description,listing_type,property_type,address,area,state,price,price_period,caution_deposit,bedrooms,bathrooms,size_sqm,furnished,status,verification_tier,amenities)
    VALUES (@id,@owner_id,@title,@description,@listing_type,@property_type,@address,@area,@state,@price,@price_period,@caution_deposit,@bedrooms,@bathrooms,@size_sqm,@furnished,@status,@verification_tier,@amenities)
  `);
  listings.forEach(l => insertListing.run({ caution_deposit: null, bedrooms: null, ...l }));
  console.log(`  ✓ ${listings.length} listings`);

  // ── VERIFICATION RECORDS ──────────────
  const insertVerif = db.prepare(`
    INSERT OR IGNORE INTO verifications (id, listing_id, owner_id, l1_status, l2_status, l3_status, l4_status, l5_status, current_layer, overall_status)
    VALUES (@id, @listing_id, @owner_id, @l1_status, @l2_status, @l3_status, @l4_status, @l5_status, @current_layer, @overall_status)
  `);
  insertVerif.run({ id: uuidv4(), listing_id: 'lst_001', owner_id: 'usr_landlord_001', l1_status: 'approved', l2_status: 'approved', l3_status: 'approved', l4_status: 'completed', l5_status: 'approved', current_layer: 5, overall_status: 'certified' });
  insertVerif.run({ id: uuidv4(), listing_id: 'lst_002', owner_id: 'usr_landlord_001', l1_status: 'approved', l2_status: 'approved', l3_status: 'approved', l4_status: 'pending', l5_status: 'pending', current_layer: 4, overall_status: 'in_progress' });
  insertVerif.run({ id: uuidv4(), listing_id: 'lst_003', owner_id: 'usr_landlord_002', l1_status: 'approved', l2_status: 'approved', l3_status: 'approved', l4_status: 'completed', l5_status: 'approved', current_layer: 5, overall_status: 'certified' });
  insertVerif.run({ id: uuidv4(), listing_id: 'lst_004', owner_id: 'usr_landlord_002', l1_status: 'approved', l2_status: 'approved', l3_status: 'pending', l4_status: 'pending', l5_status: 'pending', current_layer: 3, overall_status: 'in_progress' });
  console.log('  ✓ verification records');

  // ── ONE AGREEMENT ──────────────────────
  const agreementId = 'agr_001';
  db.prepare(`
    INSERT OR IGNORE INTO agreements (id,listing_id,landlord_id,tenant_id,agent_id,type,status,start_date,end_date,rent_amount,rent_period,caution_deposit,landlord_signed_at,tenant_signed_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
  `).run(agreementId,'lst_004','usr_landlord_002','usr_tenant_001','usr_agent_001','rental','fully_signed','2026-01-01','2026-12-31',480000,'yearly',480000,new Date().toISOString(),new Date().toISOString());

  // Rent schedule for agreement
  const insertRent = db.prepare(`INSERT OR IGNORE INTO rent_schedule (id,agreement_id,due_date,amount,status) VALUES (?,?,?,?,?)`);
  insertRent.run(uuidv4(), agreementId, '2026-01-01', 480000, 'paid');
  insertRent.run(uuidv4(), agreementId, '2027-01-01', 480000, 'upcoming');
  console.log('  ✓ agreement + rent schedule');

  // ── TRANSACTION ────────────────────────
  db.prepare(`
    INSERT OR IGNORE INTO transactions (id,reference,listing_id,payer_id,payee_id,agent_id,type,status,amount,platform_fee,agent_commission,payee_amount,description)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
  `).run('txn_001','PROPATI-2026-001','lst_004','usr_tenant_001','usr_landlord_002','usr_agent_001','rent','released',480000,48000,48000,384000,'Annual rent payment — 2-Bed Flat, Surulere');
  console.log('  ✓ transaction');

  // ── DISPUTE ────────────────────────────
  db.prepare(`
    INSERT OR IGNORE INTO disputes (id,agreement_id,raised_by,against,type,status,severity,description,amount_disputed)
    VALUES (?,?,?,?,?,?,?,?,?)
  `).run('dsp_001', agreementId, 'usr_tenant_001', 'usr_landlord_002', 'caution_refund', 'open', 2, 'Tenant vacated Jan 31. Landlord has not returned caution deposit of ₦480,000. Property was left in good condition.', 480000);
  console.log('  ✓ dispute');

  console.log('\n🎉 Seed complete! Demo accounts:');
  console.log('  Admin:    admin@propati.ng   / Admin1234!');
  console.log('  Landlord: chidi@propati.ng   / Chidi1234!');
  console.log('  Tenant:   adaeze@propati.ng  / Adaeze1234!');
  console.log('  Agent:    akin@propati.ng    / Akin1234!');
}

seed().catch(console.error);
