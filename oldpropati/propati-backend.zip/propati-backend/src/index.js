// src/index.js — PROPATI Backend Entry Point
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const path = require('path');
const { migrate } = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

// ── Run migrations on startup ──────────────────────────────
migrate();

// ── Security middleware ────────────────────────────────────
app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' } // allow serving uploaded files
}));

app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  credentials: true,
  methods: ['GET','POST','PUT','PATCH','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization']
}));

// ── Rate limiting ──────────────────────────────────────────
const globalLimit = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 min
  max: 300,
  message: { error: 'Too many requests, please slow down.' }
});

const authLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20, // strict for auth endpoints
  message: { error: 'Too many auth attempts. Try again in 15 minutes.' }
});

app.use('/api', globalLimit);
app.use('/api/auth/login', authLimit);
app.use('/api/auth/signup', authLimit);

// ── Body parsing ───────────────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ── Logging ────────────────────────────────────────────────
if (process.env.NODE_ENV !== 'test') {
  app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
}

// ── Static uploads ─────────────────────────────────────────
app.use('/uploads', express.static(path.join(process.cwd(), process.env.UPLOAD_DIR || 'uploads')));

// ── Health check ───────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'PROPATI API',
    version: '1.0.0',
    environment: process.env.NODE_ENV || 'development',
    timestamp: new Date().toISOString()
  });
});

// ── API Routes ─────────────────────────────────────────────
app.use('/api/auth',         require('./routes/auth'));
app.use('/api/listings',     require('./routes/listings'));
app.use('/api/verification', require('./routes/verification'));
app.use('/api/payments',     require('./routes/payments'));
app.use('/api/agreements',   require('./routes/agreements'));
app.use('/api/users',        require('./routes/users'));

// ── 404 ────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: `Route ${req.method} ${req.path} not found` });
});

// ── Global error handler ───────────────────────────────────
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);

  if (err.name === 'MulterError') {
    if (err.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: `File too large. Max ${process.env.MAX_FILE_SIZE_MB || 10}MB` });
    return res.status(400).json({ error: err.message });
  }

  res.status(err.status || 500).json({
    error: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message
  });
});

// ── Start ──────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`
  ╔═══════════════════════════════════════╗
  ║        PROPATI API — RUNNING          ║
  ╠═══════════════════════════════════════╣
  ║  Port:  ${PORT}                            ║
  ║  Env:   ${(process.env.NODE_ENV || 'development').padEnd(30)} ║
  ╠═══════════════════════════════════════╣
  ║  POST  /api/auth/signup               ║
  ║  POST  /api/auth/login                ║
  ║  GET   /api/listings                  ║
  ║  GET   /api/users/admin/stats         ║
  ║  GET   /health                        ║
  ╚═══════════════════════════════════════╝
  `);
});

module.exports = app;
