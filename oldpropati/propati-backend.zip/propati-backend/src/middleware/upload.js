// src/middleware/upload.js
const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');

const UPLOAD_DIR = process.env.UPLOAD_DIR || './uploads';

// Ensure upload dirs exist
['documents', 'images', 'videos'].forEach(dir => {
  const p = path.join(UPLOAD_DIR, dir);
  if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
});

function makeStorage(subdir) {
  return multer.diskStorage({
    destination: (req, file, cb) => cb(null, path.join(UPLOAD_DIR, subdir)),
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      cb(null, `${uuidv4()}${ext}`);
    }
  });
}

const allowedImageTypes = ['image/jpeg', 'image/png', 'image/webp'];
const allowedDocTypes = ['application/pdf', 'image/jpeg', 'image/png'];
const allowedVideoTypes = ['video/mp4', 'video/quicktime', 'video/webm'];

const maxSize = (process.env.MAX_FILE_SIZE_MB || 10) * 1024 * 1024;

const uploadImages = multer({
  storage: makeStorage('images'),
  limits: { fileSize: maxSize },
  fileFilter: (req, file, cb) => {
    if (allowedImageTypes.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Only JPEG, PNG, WebP images allowed'));
  }
});

const uploadDocument = multer({
  storage: makeStorage('documents'),
  limits: { fileSize: maxSize },
  fileFilter: (req, file, cb) => {
    if (allowedDocTypes.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Only PDF, JPEG, PNG documents allowed'));
  }
});

const uploadVideo = multer({
  storage: makeStorage('videos'),
  limits: { fileSize: 100 * 1024 * 1024 }, // 100MB for QR videos
  fileFilter: (req, file, cb) => {
    if (allowedVideoTypes.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Only MP4, MOV, WebM videos allowed'));
  }
});

module.exports = { uploadImages, uploadDocument, uploadVideo };
