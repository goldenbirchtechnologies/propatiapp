// src/routes/auth.js
const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const { getDb } = require('../db');
const { generateTokens, sanitizeUser, ok, fail } = require('../utils');
const { authenticate } = require('../middleware/auth');
const { verifyNIN } = require('../services/nimc');
const { createNotification } = require('../services/notifications');

// ── POST /api/auth/signup ──────────────────────────────────
router.post('/signup', [
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 8 }).matches(/^(?=.*[A-Z])(?=.*[0-9])/),
  body('full_name').trim().isLength({ min: 2 }),
  body('role').isIn(['landlord', 'tenant', 'agent']),
  body('phone').optional().isMobilePhone('any'),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return fail(res, 'Validation failed', 422, errors.array());

  const { email, password, full_name, role, phone } = req.body;
  const db = getDb();

  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) return fail(res, 'Email already registered', 409);

  const id = 'usr_' + uuidv4().replace(/-/g, '').slice(0, 16);
  const hashed = await bcrypt.hash(password, 12);

  db.prepare(`
    INSERT INTO users (id, email, phone, password, role, full_name)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(id, email, phone || null, hashed, role, full_name);

  const { access, refresh } = generateTokens(id);
  const refreshId = uuidv4();
  const refreshHash = await bcrypt.hash(refresh, 8);
  const refreshExpires = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();

  db.prepare(`INSERT INTO refresh_tokens (id, user_id, token_hash, expires_at) VALUES (?, ?, ?, ?)`)
    .run(refreshId, id, refreshHash, refreshExpires);

  createNotification(id, 'welcome', 'Welcome to PROPATI! 🏠', `Hi ${full_name.split(' ')[0]}, your account is ready. Complete your KYC to unlock all features.`);

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  return ok(res, { message: 'Account created', user: sanitizeUser(user), access_token: access, refresh_token: refresh }, 201);
});

// ── POST /api/auth/login ───────────────────────────────────
router.post('/login', [
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty(),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return fail(res, 'Validation failed', 422, errors.array());

  const { email, password } = req.body;
  const db = getDb();

  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user) return fail(res, 'Invalid email or password', 401);
  if (user.is_banned) return fail(res, 'Account suspended. Contact support@propati.ng', 403);
  if (!user.is_active) return fail(res, 'Account deactivated', 403);

  const match = await bcrypt.compare(password, user.password);
  if (!match) return fail(res, 'Invalid email or password', 401);

  db.prepare('UPDATE users SET last_login = datetime("now") WHERE id = ?').run(user.id);

  const { access, refresh } = generateTokens(user.id);
  const refreshId = uuidv4();
  const refreshHash = await bcrypt.hash(refresh, 8);
  const refreshExpires = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();

  // Clean old refresh tokens for this user
  db.prepare('DELETE FROM refresh_tokens WHERE user_id = ? AND expires_at < datetime("now")').run(user.id);
  db.prepare('INSERT INTO refresh_tokens (id, user_id, token_hash, expires_at) VALUES (?, ?, ?, ?)')
    .run(refreshId, user.id, refreshHash, refreshExpires);

  return ok(res, { user: sanitizeUser(user), access_token: access, refresh_token: refresh });
});

// ── POST /api/auth/refresh ─────────────────────────────────
router.post('/refresh', async (req, res) => {
  const { refresh_token } = req.body;
  if (!refresh_token) return fail(res, 'Refresh token required', 400);

  let payload;
  try {
    payload = jwt.verify(refresh_token, process.env.JWT_REFRESH_SECRET);
  } catch {
    return fail(res, 'Invalid or expired refresh token', 401);
  }

  const db = getDb();
  const tokens = db.prepare('SELECT * FROM refresh_tokens WHERE user_id = ? AND expires_at > datetime("now")').all(payload.sub);

  let valid = false;
  for (const t of tokens) {
    if (await bcrypt.compare(refresh_token, t.token_hash)) { valid = true; break; }
  }
  if (!valid) return fail(res, 'Refresh token not recognised', 401);

  const { access, refresh: newRefresh } = generateTokens(payload.sub);
  return ok(res, { access_token: access, refresh_token: newRefresh });
});

// ── POST /api/auth/logout ──────────────────────────────────
router.post('/logout', authenticate, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM refresh_tokens WHERE user_id = ?').run(req.user.id);
  return ok(res, { message: 'Logged out' });
});

// ── GET /api/auth/me ───────────────────────────────────────
router.get('/me', authenticate, (req, res) => {
  return ok(res, { user: sanitizeUser(req.user) });
});

// ── POST /api/auth/kyc/nin ─────────────────────────────────
// Verify NIN via NIMC API
router.post('/kyc/nin', authenticate, [
  body('nin').isLength({ min: 11, max: 11 }).isNumeric(),
  body('first_name').trim().notEmpty(),
  body('last_name').trim().notEmpty(),
  body('date_of_birth').isISO8601(),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return fail(res, 'Validation failed', 422, errors.array());

  const { nin, first_name, last_name, date_of_birth } = req.body;
  const result = await verifyNIN(nin, first_name, last_name, date_of_birth);

  if (!result.success) return fail(res, result.error || 'NIN verification failed', 400);

  const db = getDb();
  db.prepare('UPDATE users SET nin = ?, nin_verified = 1, updated_at = datetime("now") WHERE id = ?')
    .run(nin, req.user.id);

  createNotification(req.user.id, 'kyc_success', 'NIN Verified ✓', 'Your NIN has been verified successfully. You can now list properties.');

  return ok(res, { message: 'NIN verified successfully', verified: true });
});

// ── PATCH /api/auth/password ───────────────────────────────
router.patch('/password', authenticate, [
  body('current_password').notEmpty(),
  body('new_password').isLength({ min: 8 }).matches(/^(?=.*[A-Z])(?=.*[0-9])/),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return fail(res, 'Validation failed', 422, errors.array());

  const { current_password, new_password } = req.body;
  const db = getDb();
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);

  if (!await bcrypt.compare(current_password, user.password)) return fail(res, 'Current password is incorrect', 401);

  const hashed = await bcrypt.hash(new_password, 12);
  db.prepare('UPDATE users SET password = ?, updated_at = datetime("now") WHERE id = ?').run(hashed, req.user.id);
  db.prepare('DELETE FROM refresh_tokens WHERE user_id = ?').run(req.user.id);

  return ok(res, { message: 'Password updated. Please log in again.' });
});

module.exports = router;
