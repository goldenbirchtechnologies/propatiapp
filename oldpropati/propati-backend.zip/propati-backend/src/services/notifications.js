// src/services/notifications.js
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../db');

// ── IN-APP NOTIFICATION ────────────────────────────────────
function createNotification(userId, type, title, body, data = null) {
  try {
    const db = getDb();
    db.prepare(`
      INSERT INTO notifications (id, user_id, type, title, body, data)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(uuidv4(), userId, type, title, body, data ? JSON.stringify(data) : null);
  } catch (e) {
    console.error('Notification insert error:', e.message);
  }
}

// ── SMS ────────────────────────────────────────────────────
async function sendSMS(phone, message) {
  if (process.env.NODE_ENV !== 'production' || !process.env.TWILIO_ACCOUNT_SID) {
    console.log(`[SMS → ${phone}]: ${message}`);
    return { success: true, mock: true };
  }
  try {
    const twilio = require('twilio')(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
    const result = await twilio.messages.create({
      body: message,
      from: process.env.TWILIO_PHONE_NUMBER,
      to: phone
    });
    return { success: true, sid: result.sid };
  } catch (e) {
    console.error('SMS error:', e.message);
    return { success: false, error: e.message };
  }
}

// ── EMAIL ──────────────────────────────────────────────────
async function sendEmail(to, subject, html) {
  if (process.env.NODE_ENV !== 'production' || !process.env.SENDGRID_API_KEY) {
    console.log(`[EMAIL → ${to}]: ${subject}`);
    return { success: true, mock: true };
  }
  try {
    const sgMail = require('@sendgrid/mail');
    sgMail.setApiKey(process.env.SENDGRID_API_KEY);
    await sgMail.send({ to, from: process.env.EMAIL_FROM, subject, html });
    return { success: true };
  } catch (e) {
    console.error('Email error:', e.message);
    return { success: false, error: e.message };
  }
}

// ── NAMED NOTIFICATION TEMPLATES ──────────────────────────
async function notifyRentDue(tenant, agreement, daysUntilDue) {
  const msg = `PROPATI: Your rent of ₦${agreement.rent_amount.toLocaleString()} is due in ${daysUntilDue} day(s). Pay at propati.ng`;
  createNotification(tenant.id, 'rent_due', 'Rent Due Soon', `Your rent is due in ${daysUntilDue} days`, { agreement_id: agreement.id });
  if (tenant.phone) await sendSMS(tenant.phone, msg);
}

async function notifyVerificationUpdate(owner, listingTitle, layer, status) {
  const title = `Verification Layer ${layer} ${status}`;
  const body = `${listingTitle}: Layer ${layer} has been ${status}`;
  createNotification(owner.id, 'verification_update', title, body, { layer, status });
  if (owner.email) await sendEmail(owner.email, title, `<p>${body}</p><p>Log in at propati.ng to continue.</p>`);
}

async function notifyPaymentReceived(landlord, amount, listingTitle) {
  const msg = `PROPATI: Payment of ₦${amount.toLocaleString()} received for ${listingTitle} and held in escrow.`;
  createNotification(landlord.id, 'payment_received', 'Payment Received', msg);
  if (landlord.phone) await sendSMS(landlord.phone, msg);
}

async function notifyEscrowReleased(landlord, amount) {
  const msg = `PROPATI: ₦${amount.toLocaleString()} has been released from escrow to your account.`;
  createNotification(landlord.id, 'escrow_released', 'Escrow Released', msg);
  if (landlord.phone) await sendSMS(landlord.phone, msg);
}

module.exports = { createNotification, sendSMS, sendEmail, notifyRentDue, notifyVerificationUpdate, notifyPaymentReceived, notifyEscrowReleased };
