// src/utils/index.js
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');

// Generate access + refresh token pair
function generateTokens(userId) {
  const access = jwt.sign({ sub: userId }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '15m'
  });
  const refresh = jwt.sign({ sub: userId, type: 'refresh' }, process.env.JWT_REFRESH_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d'
  });
  return { access, refresh };
}

// Strip sensitive fields from user object
function sanitizeUser(user) {
  if (!user) return null;
  const { password, nin, bvn, ...safe } = user;
  return safe;
}

// Compute platform fee based on transaction type and amount
function computeFees(type, amount) {
  const rates = {
    rent: 0.10,       // 10% of annual rent
    sale: amount > 20_000_000 ? 0.01 : 0.02,
    short_let: 0.05,
    commercial: 0.08,
    share: 0.05,
  };
  const agentRates = {
    rent: 0.10,       // agent gets 10% of annual rent too
    sale: amount > 20_000_000 ? 0.01 : 0.015,
    short_let: 0.03,
    commercial: 0.05,
  };
  const feeRate = rates[type] || 0.10;
  const agentRate = agentRates[type] || 0;
  const platformFee = Math.round(amount * feeRate);
  const agentCommission = Math.round(amount * agentRate);
  const payeeAmount = amount - platformFee;
  return { platformFee, agentCommission, payeeAmount };
}

// Build pagination metadata
function paginate(total, page, limit) {
  const pages = Math.ceil(total / limit);
  return { total, page, limit, pages, hasNext: page < pages, hasPrev: page > 1 };
}

// Generate a unique Paystack-style reference
function generateRef() {
  return `PROPATI-${Date.now()}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
}

// Generate verification QR code string (24hr expiry)
function generateQRCode() {
  const code = `PROPATI-QR-${uuidv4().toUpperCase()}`;
  const expires = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
  return { code, expires };
}

// Simple success/error response helpers
function ok(res, data, status = 200) {
  return res.status(status).json({ success: true, ...data });
}
function fail(res, message, status = 400, details = null) {
  const resp = { success: false, error: message };
  if (details) resp.details = details;
  return res.status(status).json(resp);
}

module.exports = { generateTokens, sanitizeUser, computeFees, paginate, generateRef, generateQRCode, ok, fail };
